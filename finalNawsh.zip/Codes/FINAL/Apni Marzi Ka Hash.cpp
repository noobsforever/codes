#include <bits/stdc++.h>
using namespace std;

class hashtable
{
	int size;
	int*table;
	int collisions;
	public:
	hashtable(int size)
	{
		int i;
		collisions=0;
		this->size=size;
		table=new int[size];
		for(i=0;i<size;i++)
		{
			table[i]=-1;
		}
	}
	int getIndex(int val)
	{
		int index=(val+5)%size;//hashing function
		return index;
	}
	void changeValue(int index)
	{
		table[index]=-1;//INDICATES EMPTY VALUE
	}
	int getVal(int index)
	{
		return table[index];
	}
	bool isFull()
	{
		int i;
		for(i=0;i<size;i++)
		{
			if(table[i]==-1)
			return false;
		}
		return true;
	}
	void insertVal(int val)
	{
		int index=getIndex(val);
		if(table[index]==-1)
		{
			table[index]=val;
		}else
		{
			for(;;)
			{
				if(isFull())
				{
					cout<<"Table Is Full."<<endl;
					break;
				}
				if(index==size-1)
				{
					break;
				}
				if(table[index]==-1)
				{
					table[index]=val;
					collisions++;
					break;
				}
				index++;
			}
		}
	}
	int getCollisions()
	{
		return collisions;
	}
	void display()
	{
		int i;
		for(i=0;i<size;i++)
		{
			cout<<"Index = "<<i<<endl;
			cout<<"Value At This Index = "<<getVal(i)<<endl<<endl;
		}
	}
};
int main()
{
	hashtable h(10);
	h.insertVal(1);
	h.insertVal(11);
	h.insertVal(3);
	h.insertVal(4);
	h.insertVal(5);
	h.insertVal(6);
	h.insertVal(7);
	cout<<"Number Of Collisions = "<<h.getCollisions()<<endl<<endl;
	h.display();
	return 0;
}
