#include <bits/stdc++.h>
using namespace std;

class hashtable
{
	int size;
	int*table;
	public:
	hashtable(int size)
	{
		int i;
		this->size=size;
		table=new int[size];
		for(i=0;i<size;i++)
		{
			table[i]=0;
		}
	}
	int getIndex(int val)
	{
		int index=(val-97)%26;
		return index;
	}
	void valueIncrement(int index)
	{
		table[index]++;
	}
	void changeValue(int index)
	{
		table[index]=-1;//already visited
	}
	int getCount(int index)
	{
		return table[index];
	}
	void removeDup(string s)
	{
		string clone;
		int i,x;
		for(i=0;i<s.length();i++)
		{
			x=getIndex(s[i]);
			valueIncrement(x);
		}
		for(i=0;i<s.length();i++)
		{
			if(getCount(getIndex(s[i]))>0)
			{
				clone+=s[i];
				changeValue(getIndex(s[i]));
			}
		}
		cout<<clone;
	}
};
int main()
{
	hashtable h(26);
	h.removeDup("thisishashing");
	return 0;
}
