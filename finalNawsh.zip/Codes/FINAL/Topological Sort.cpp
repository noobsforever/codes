#include<iostream>
#include<vector>
#include<stack>
using namespace std;
template <class T>
class queue
{
    public:
    queue()
    {
        
    }
    void clear()
    {
        st.clear();
    }
    bool isEmpty()
    {
        return st.empty();
    }
    T Top()
    {
        return st.front();
    }
    T Dequeue()
    {	
    	if(!st.empty()){
    		T el;
	        el=st.front();
	        st.erase(st.begin());
	        return el;
		}
    }
    void Enqueue(T el)
    {
        st.push_back(el);
    }
    void Display()
    {
        for(int itr=0; itr<st.size(); itr++)
        {
            cout<<st[itr]<<endl;
        }
    }
    private:
    vector <T> st;
};
class Graph{
	int num;
	vector<int>* neighbour;
	bool* isVisited;
	int* inDegree;
	int* outDegree;
	int* vertices;
	private: 
		void bfs_(int s, queue<int>& q){
			isVisited[s] = true;
			for(int x = 0; x < neighbour[s].size(); x++){
				if(!isVisited[neighbour[s][x]]){
					q.Enqueue(neighbour[s][x]);
					isVisited[neighbour[s][x]] = true;
				}
			}
			if(!q.isEmpty()){
				int hold = q.Dequeue();
				cout << hold << " ";
				bfs_(q.Top(), q);
			}
		}
		int minInDegree(){
			int min = 0;
			while(isVisited[min]){
				min++;
			}
			int inDg = inDegree[min];
			for(int x = 1; x < num; x++){
				if(inDg > inDegree[x] && isVisited[x] == false){
					min = x;
					inDg = inDegree[x];
					isVisited[x] = true;
				}
			}
			isVisited[min] = true;
			return min;
		}
	public:
		Graph(){
		}
		Graph(int num){
			this->num = num;
			isVisited = new bool[num];
			neighbour = new vector<int>[num];
			inDegree = new int[num];
			outDegree = new int[num];
			vertices = new int[num];
			for(int x = 0; x < num; x++){
				isVisited[x] = false;
				inDegree[x] = 0;
				outDegree[x] = 0;
				vertices[x] = x;
			}
		}
		void add_edge(int u, int v){
			neighbour[u].push_back(v);
			inDegree[v]++;
			outDegree[u]++;
		}
		
		void dfs(int s){
			stack<int> st;
			st.push(s);
			cout << s << " ";
			isVisited[s] = true;
			for(int x = 0; x < neighbour[s].size(); x++){
				if(!isVisited[neighbour[s][x]]){
					dfs(neighbour[s][x]);
				}
			}
		}
		void reset(){
			for(int x = 0; x < num; x++){
				isVisited[x] = false;
			}
		}
		void bfs(int s){
			queue<int> q;
			q.Enqueue(s);
			bfs_(s, q);
		}
		void topologicalSort(){
			for(int x = 0; x < num; x++){
				int min = minInDegree();
				cout << min << " ";
				for(int y = 0; y < neighbour[min].size(); y++){
					inDegree[neighbour[min][y]]--;
				}	
			}
		}
};
int main(){
	Graph graph(5);
	graph.add_edge(1, 0);
	graph.add_edge(2, 0);
	graph.add_edge(3, 0);
	graph.add_edge(1, 4);
	graph.add_edge(2, 4);
	graph.add_edge(3, 4);
//	graph.dfs(0);  //0 vertex as the souce vertex
//	graph.reset();
//	cout << endl;
//	graph.bfs(0);
	graph.topologicalSort();
}
