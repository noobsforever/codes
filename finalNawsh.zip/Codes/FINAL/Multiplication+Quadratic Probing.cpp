#include <bits/stdc++.h>
using namespace std;

class hashtable
{
	int size;
	int*table;
	int collisions;
	float a;
	public:
	hashtable(int size)
	{
		int i;
		a=0.234;
		collisions=0;
		this->size=size;
		table=new int[size];
		for(i=0;i<size;i++)
		{
			table[i]=-1;
		}
	}
	int getIndex(int val)
	{
		int index=0;
		float s=(float)val*a;
		s-=floor(s);
		index=floor(s*size);
		return index;
	}
	void changeValue(int index)
	{
		table[index]=-1;//INDICATES EMPTY VALUE
	}
	int getVal(int index)
	{
		return table[index];
	}
	bool isFull()
	{
		int i;
		for(i=0;i<size;i++)
		{
			if(table[i]==-1)
			return false;
		}
		return true;
	}
	void insertVal(int val)
	{
		int index=getIndex(val);
		if(table[index]==-1)
		{
			table[index]=val;
		}else
		{
			int k=0;
			for(;;)
			{
				if(isFull())
				{
					cout<<"Table Is Full."<<endl;
					break;
				}
				if(table[index]==-1)
				{
					table[index]=val;
					collisions++;
					break;
				}
				index=(index+(k*k))%size;//quadratic probing
				k++;
			}
		}
	}
	int getCollisions()
	{
		return collisions;
	}
	void display()
	{
		int i;
		for(i=0;i<size;i++)
		{
			cout<<"Index = "<<i<<endl;
			cout<<"Value At This Index = "<<getVal(i)<<endl<<endl;
		}
	}
};
int main()
{
	hashtable h(15);
	h.insertVal(24);
	h.insertVal(102);
	h.insertVal(990);
	h.insertVal(50);
	h.insertVal(51);
	h.insertVal(60);
	cout<<"Number Of Collisions = "<<h.getCollisions()<<endl<<endl;
	h.display();
	return 0;
}
