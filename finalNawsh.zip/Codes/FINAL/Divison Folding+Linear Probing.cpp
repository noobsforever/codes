#include <bits/stdc++.h>
using namespace std;

class hashtable
{
	int size;
	int*table;
	int collisions;
	public:
	hashtable(int size)
	{
		int i;
		collisions=0;
		this->size=size;
		table=new int[size];
		for(i=0;i<size;i++)
		{
			table[i]=-1;
		}
	}
	int getIndex(int val)
	{
		int index=0;
		while(val!=0)
		{
			index+=val%10;
			val/=10;
		}
		index=index%size;
		return index;
	}
	bool isFull()
	{
		int i;
		for(i=0;i<size;i++)
		{
			if(table[i]==-1)
			return false;
		}
		return true;
	}
	void changeValue(int index)
	{
		table[index]=-1;//INDICATES EMPTY VALUE
	}
	int getVal(int index)
	{
		return table[index];
	}
	void insertVal(int val)
	{
		int index=getIndex(val);
		if(table[index]==-1)
		{
			table[index]=val;
		}else
		{
			for(;;)
			{
				if(isFull())
				{
					cout<<"Table Is Full."<<endl;
					break;
				}
				if(index==size-1)
				{
					break;
				}
				if(table[index]==-1)
				{
					table[index]=val;
					collisions++;
					break;
				}
				index++;
			}
		}
	}
	int getCollisions()
	{
		return collisions;
	}
	void display()
	{
		int i;
		char c;
		for(i=0;i<size;i++)
		{
			cout<<"Index = "<<i<<endl;
			c=(int)getVal(i);
			if(c==-1)
			{
				cout<<"Value At This Index = "<<-1<<endl<<endl;
			}else
				cout<<"Value At This Index = "<<(char)c<<endl<<endl;
		}
	}
};
int main()
{
	hashtable h(12);
	h.insertVal('A');
	h.insertVal('B');
	h.insertVal('M');
	h.insertVal('G');
	h.insertVal('K');
	h.insertVal('Y');
	cout<<"Number Of Collisions = "<<h.getCollisions()<<endl<<endl;
	h.display();
	return 0;
}
