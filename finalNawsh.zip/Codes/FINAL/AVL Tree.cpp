#include "stdafx.h"
#include <iostream>
#include <conio.h>
using namespace std;
//Global variables
int flag=0;
// An AVL tree node

class node
{
public:
    int key;
    node *left;
    node *right;
    int height;
};

//Class Declaration
class avlTree
{
    public:
			node *root;
           int max(int a, int b);
           int avlTree::height(node *N);
           node* newNode(int key);
           void display(node *ptr, int level);
           node* rightRotate(node *y);
           node* leftRotate(node *x);
           int getBalance(node *N);
           node* insert(node* node, int key);
           node * minValueNode(node* node);
           void preOrder(node *root);
           void postOrder(node *root);
           void inOrder(node *root);
           void search(int);
        //Default constructor
        avlTree()
        {
            root = NULL;
        }
};

void avlTree::search(int key)
//Searches for a specific node in the AVL-tree
{
     node *temp = root,*parent = root;
    if(temp==NULL)
        cout<<"\nThe AVL Tree is empty\n"<<endl;
    else
    {
        while(temp!=NULL && temp->key!=key)
        {
            parent=temp;
            if(temp->key<key)
            {
                temp=temp->right;
            }
            else
            {
                temp=temp->left;
            }
        }
    }
    
    if(temp==NULL)
        cout<<"This element is NOT present in the tree!";
    else
        {cout<<"\nThis element is present in the tree! ";
        cout<<"\nIt's height is: "<<temp->height;
        }
        
}


// A function to get maximum of two integers
int avlTree::max(int a, int b)
{
    return (a > b)? a : b;
}
 
// A function to get height of the tree
int avlTree::height( node *N)
{
    if (N == NULL)
        return 0;
    return N->height;
}
//A function to display AVL Tree
void avlTree::display(node *ptr, int level)
{
    int i;
    if (ptr!=NULL)
    {
        display(ptr->right, level + 1);
        printf("\n");
        if (ptr == root)
        cout<<"Root -> ";
        for (i = 0; i < level && ptr != root; i++)
            cout<<"        ";
        cout<<ptr->key;
        display(ptr->left, level + 1);
    }
}

 
/* Function that allocates a new node with the given key and
    NULL left and right pointers. */
 node* avlTree::newNode(int key)
{
     node* leaf = new node;
    leaf->key   = key;
    leaf->left   = NULL;
    leaf->right  = NULL;
    leaf->height = 1;  // new node is initially added at leaf
    return(leaf);
}
 
// A function to right rotate subtree rooted with y
 node* avlTree::rightRotate( node *y)
{
     node *x = y->left;
     node *T2 = x->right;
     // Perform rotation
    x->right = y;
    y->left = T2;
     // Update heights
    y->height = max(height(y->left), height(y->right))+1;
    x->height = max(height(x->left), height(x->right))+1;
     // Return new root
    return x;
}
 
// A function to left rotate subtree rooted with x
 node* avlTree::leftRotate( node *x)
{
     node *y = x->right;
     node *T2 = y->left;
    // Perform rotation
    y->left = x;
    x->right = T2;
    //  Update heights
    x->height = max(height(x->left), height(x->right))+1;
    y->height = max(height(y->left), height(y->right))+1;
    // Return new root
    return y;
}
 
//A function to get the balance factor of node N
int avlTree::getBalance( node *N)
{
    if (N == NULL)
        return 0;
    return height(N->left) - height(N->right);
}
//A function to delete a selected node
 node* avlTree::insert( node* node, int key)
{
    //First we perform a normal BST rotation
    if (node == NULL)
        return(newNode(key));
    if (key < node->key)
        node->left  = insert(node->left, key);
    else
        node->right = insert(node->right, key);
    //Then we update the height of this ancestor node
    node->height = max(height(node->left), height(node->right)) + 1;
    //Get the balance factor of this ancestor node to check whether this node became unbalanced
    int balance = getBalance(node);
    //If this node becomes unbalanced, then 4 cases arise
    // 1.Left Left Case
    if (balance > 1 && key < node->left->key)
        return rightRotate(node);
    // 2.Right Right Case
    if (balance < -1 && key > node->right->key)
        return leftRotate(node);
    // 3.Left Right Case
    if (balance > 1 && key > node->left->key)
    {
        node->left =  leftRotate(node->left);
        return rightRotate(node);
    }
    // 4.Right Left Case
    if (balance < -1 && key < node->right->key)
    {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }
    /* Return the (unchanged) node pointer */
    return node;
}
//A function return the node with minimum key value found in the non-empty binary search tree.
 node * avlTree::minValueNode( node* leaf)
{
     node* current = leaf;
    //Loop to find the leftmost leaf */
    while (current->left != NULL)
        current = current->left;
    return current;
}


//A function to print preorder traversal of the tree.
void avlTree::preOrder( node *root)
{
    if(root != NULL)
    {
        printf("%d ", root->key);
        preOrder(root->left);
        preOrder(root->right);
    }
}
//A function to print postrder traversal of the tree.
void avlTree::postOrder( node *root)
{
    if(root != NULL)
    {
        postOrder(root->left);
        postOrder(root->right);
        printf("%d ", root->key);
    }
}
//A function to print inorder traversal of the tree.
void avlTree::inOrder( node *root)
{
    if(root != NULL)
    {
        inOrder(root->left);
        printf("%d ", root->key);
        inOrder(root->right);
    }
}



int main()
{
    avlTree avl;
	
	// insertion
	int item;
	cout<<"Enter value to be inserted: ";
    cin>>item;
    avl.root = avl.insert(avl.root, item);
	cout<<"Enter value to be inserted: ";
    cin>>item;
    avl.root = avl.insert(avl.root, item);
	cout<<"Enter value to be inserted: ";
    cin>>item;
    avl.root = avl.insert(avl.root, item);

	// display
	avl.display(avl.root, 1);
    
	// inorder traversal
    cout<<"\n\nInorder Traversal:"<<endl;
    avl.inOrder(avl.root);
}
