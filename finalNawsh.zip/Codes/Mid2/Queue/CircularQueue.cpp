using namespace std;
#include<bits/stdc++.h>
class node
{
	public:
		int data;
		node* next;
};

class Queue
{
	public:
		node* head;
		Queue()
		{
			head=NULL;
		}
		void Enqueue(int a)
		{
			node* n=head;
			if(head==NULL)
			{
				node* temp=new node();
				temp->data=a;
				head=temp;
				temp->next=head;
			}else
			{
				while(1)
				{
					if(n->next==head)
					break;
					else
					n=n->next;
				}
				node* temp=new node();
				temp->data=a;
				n->next=temp;
				temp->next=head;
			}
		}
		bool isEmpty()
		{
			if(count()==0)
			{
				return true;
			}else 
			return false;
		}
		void Dequeue()
		{
			if(isEmpty())
			cout<<"Queue Empty."<<endl;
		else if(count()==1)
		{
			node*temp=head;
			free(temp);
			head=NULL;
		}
		else
		{
			node*temp=head->next;
			node*temp2=head;
			node*temp3=head;
			while(1)
			{
				if(temp2->next==head)
				break;
				else
				{
					temp2=temp2->next;
				}
			}
			free(temp3);
			head=temp;
			temp2->next=temp;
		}
		}
		void display()
		{
			node*check=head;
			if(isEmpty())
			cout<<"The Queue Is Empty."<<endl;
			else
			{
				cout<<"Queue Data: ";
				while(check->next!=head)
				{
					cout<<check->data<<"  ";
					check=check->next;
				}
				cout<<check->data<<"  ";
				check=check->next;
				cout<<endl;
			}
		}
		int count()
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(n->next==head)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return c;
		}
		node* indexer(int x)
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(c==x)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return n;
		}
};
int main()
{
	Queue l;
	l.display();
	l.Enqueue(1);
	l.Enqueue(2);
	l.Enqueue(3);
	l.Enqueue(4);
	l.Enqueue(5);
	l.display();
	l.Dequeue();
	l.display();
	l.Dequeue();
	l.display();
	l.display();
	cout<<"SIZE = "<<l.count()<<endl;
	return 0;
}
