using namespace std;
#include<bits/stdc++.h>
class node
{
	public:
		int data;
		node* next;
};

class Queue
{
	public:
		node* head;
		Queue()
		{
			head=NULL;
		}
		void Enqueue(int a)
		{
			node* n=head;
			if(head==NULL)
			{
				node* temp=new node();
				temp->data=a;
				temp->next=NULL;
				head=temp;
			}else
			{
				while(n->next!=NULL)
				{
					n=n->next;
				}
				node* temp=new node();
				temp->data=a;
				temp->next=NULL;
				n->next=temp;
			}
		}
		bool isEmpty()
		{
			if(count()==0)
			{
				return true;
			}else 
			return false;
		}
		void Dequeue()
		{
			if(count()==0)
			cout<<"Queue Empty."<<endl;
			else
			{
				node* n=head;
				node*temp=n;
				head=n->next;
				free(temp);
			}
		}
		void display()
		{
			node*check=head;
			if(isEmpty())
			cout<<"The Queue Is Empty."<<endl;
			else
			{
				cout<<"Queue Data: ";
				while(check!=NULL)
				{
					cout<<check->data<<"  ";
					check=check->next;
				}
				cout<<endl;
			}
		}
		int count()
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(n->next==NULL)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return c;
		}
		node* indexer(int x)
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(c==x)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return n;
		}
		void change(int data,int pos)
		{
			if(count()==0)
			{
				cout<<"Queue Empty"<<endl;
			}else
			{
				pos++;
				if(pos<1||pos>count())
				{
					cout<<"Invalid Index"<<endl;
				}else
				{
					indexer(pos)->data=data;
					cout<<"Value Updated"<<endl;
				}
			}
		}
		void peek(int pos)
		{
			if(count()==0)
			{
				cout<<"Queue Empty"<<endl;
			}else
			{
				pos++;
				if(pos<1||pos>count())
				{
					cout<<"Invalid Index"<<endl;
				}else
				{
					cout<<"Data At Index "<<pos-1<<" = "<<indexer(pos)->data<<endl;
				}
			}
		}
};
int main()
{
	Queue l;
	l.display();
	l.Enqueue(1);
	l.Enqueue(2);
	l.Enqueue(3);
	l.Enqueue(4);
	l.Enqueue(5);
	l.display();
	l.Dequeue();
	l.display();
	l.Dequeue();
	l.display();
	l.display();
	cout<<"SIZE = "<<l.count()<<endl;
	return 0;
}
