using namespace std;
#include<bits/stdc++.h>
class node
{
	public:
		int data;
		node* next;
};

class Stack
{
	public:
		node* head;
		Stack()
		{
			head=NULL;
		}
		void push(int a)
		{
			node* temp=new node();
			if(head==NULL)
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}else
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}
		}
		bool isEmpty()
		{
			if(count()==0)
			{
				return true;
			}else 
			return false;
		}
		void pop()
		{
			if(count()==0){}
			else
			{
				node* n=head;
				node*temp=n;
				head=n->next;
				cout<<"Data Popped : "<<temp->data<<endl;
				free(temp);
			}
		}
		void display()
		{
			node*check=head;
			if(head==NULL)
			cout<<"The Stack Is Empty."<<endl;
			else
			{
				cout<<"Stack Data: ";
				while(check!=NULL)
				{
					cout<<check->data<<"  ";
					check=check->next;
				}
				cout<<endl;
			}
		}
		void display2()
		{
			node*check=head;
			if(head==NULL)
			cout<<"The Queue Is Empty."<<endl;
			else
			{
				cout<<"Queue Data: ";
				while(check!=NULL)
				{
					cout<<check->data<<"  ";
					check=check->next;
				}
				cout<<endl;
			}
		}
		int count()
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(n->next==NULL)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return c;
		}
		node* indexer(int x)
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(c==x)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return n;
		}
};
void stackToQueue(Stack*,Stack*);
int main()
{
	Stack s1,s2;
	s1.push(1);
	s1.push(2);
	s1.push(3);
	s1.push(4);
	s1.push(5);
	s1.display();
	stackToQueue(&s1,&s2);//Whatever is In Stack 1 will be reversed and copied to Stack 2
	s2.display2();
	s2.pop();//Will pop 1 from Stack 2
	s2.display2();
	return 0;
}

void stackToQueue(Stack*s1,Stack*s2)
{
	int i,c=s1->count();
	
	for(i=0;i<c;i++)
	{
		s2->push(s1->indexer(i+1)->data);
	}
}
