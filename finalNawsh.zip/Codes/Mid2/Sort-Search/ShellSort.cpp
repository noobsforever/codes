#include<bits/stdc++.h>
using namespace std;
void shellSort(int [],int);
void display(int [],int);
int main()
{
	int size=10;
	int arr[size]={88,9,77,7,6,5,4,3,2,1};
	shellSort(arr,size);
	display(arr,size);
	return 0;
}
void display(int arr[],int size)
{
	int i;
	for(i=0;i<size;i++)
	{
		cout<<arr[i]<<" ";
	}
}
void shellSort(int arr[],int size)
		{  
   			int temp,i,gap,j;
			for(gap=size/2;gap>0;gap/=2)
			{
				for(i=gap;i<size;i++)
				{
					temp=arr[i];
					j=0;
					for(j=i;j>=gap&&arr[j-gap]>temp;j-=gap)
					{
						swap(arr[j],arr[j-gap]);
					}
					arr[j]=temp;
				}
			}
		}
