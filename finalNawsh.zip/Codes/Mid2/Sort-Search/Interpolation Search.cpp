#include<bits/stdc++.h>
using namespace std;

bool binSearch(int[],int,int,int);
int main()
{
	int arr[]={9,2,8,1,3,5,7,10};
	int size=sizeof(arr)/sizeof(int);
	int searchVal=5;
	sort(arr,arr+size);//Initial Sort
	if(binSearch(arr,0,size-1,searchVal))
	cout<<"Value Found."<<endl;
	else 
	cout<<"Value Not Found."<<endl;
	return 0;
}
bool binSearch(int arr[],int left,int right,int val)
{
	int mid = left+(((right-left)/(arr[right]-arr[left]))*(val - arr[left]));
	if(arr[mid]==val)
	return true;
	else if(left>=right)
	return false;
	else
	{	
		if(val>arr[mid])
		{
			return binSearch(arr,mid+1,right,val);
		}else
		{
			return binSearch(arr,left,mid-1,val);
		}
	}
}
