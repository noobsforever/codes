#include<bits/stdc++.h>
using namespace std;
void insertionSort(int [],int);
void display(int [],int);
int main()
{
int size=10;
int arr[size]={10,9,8,7,6,5,4,3,2,1};
insertionSort(arr,size);
display(arr,size);
return 0;
}
void display(int arr[],int size)
{
int i;
for(i=0;i<size;i++)
{
cout<<arr[i]<<" ";
}
}
void insertionSort(int arr[],int size)
{
int i,key,j;
 for(i=0;i<size;i++)
 {
 key=arr[i];
 j=i-1;
 while(j>=0 &&arr[j]>key)
 {
 arr[j+1]=arr[j];
 j=j-1;
 }
 arr[j+1]=key;
 }
}
