#include<bits/stdc++.h>
using namespace std;
void selectionSort(int [],int);
void display(int [],int);
int main()
{
	int size=10;
	int arr[size]={10,9,8,7,6,5,4,3,2,1};
	selectionSort(arr,size);
	display(arr,size);
	return 0;
}
void display(int arr[],int size)
{
	int i;
	for(i=0;i<size;i++)
	{
		cout<<arr[i]<<" ";
	}
}
void selectionSort(int arr[],int size)  
		{  
   			int i,j,min;  
    		for (i=0;i<size;i++)  
    		{  
        		min=i;
        		for (j=i+1;j<size;j++)  
        		if(arr[j]<arr[min])  
         	  	min=j;
        		swap(arr[min],arr[i]);  
    		}  
		}
