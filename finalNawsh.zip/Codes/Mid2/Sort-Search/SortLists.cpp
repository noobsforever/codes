using namespace std;
#include<bits/stdc++.h>
class node
{
	public:
		int data;
		node* next;
};
class lister
{
	public:
		node* head;
		lister()
		{
			head=NULL;
		}
		void addBegin(int a)
		{
			node* temp=new node();
			if(head==NULL)
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}else
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}
		}
		void addEnd(int a)
		{
			node* n=head;
			if(head==NULL)
			{
				node* temp=new node();
				temp->data=a;
				temp->next=NULL;
				head=temp;
			}else
			{
				while(n->next!=NULL)
				{
					n=n->next;
				}
				node* temp=new node();
				temp->data=a;
				temp->next=NULL;
				n->next=temp;
			}
		}
		void addMiddle(int a,int pos)
		{
			if(count()==0)
			{
				addBegin(a);
				cout<<"List Empty, Added Node At Beginning."<<endl;
			}else if(pos<1||pos>count()+1)
			{
				cout<<"Please Enter A Valid Postion."<<endl;
			}else
			{
				if(pos==1)
				{
					addBegin(a);
				}else if(pos==count()+1)
				{
					addEnd(a);
				}else
				{
					int i=0;
					node*temp=new node();
					node*n=head;
					while(i!=pos-2)
					{
						cout<<"i="<<i<<" n="<<n->data<<endl;
						i++;
						n=n->next;
					}
					temp->data=a;
					temp->next=n->next;
					n->next=temp;
				}
			}
		}
		void deleteBegin()
		{
			if(count()==0)
			cout<<"List Empty."<<endl;
			else
			{
				node* n=head;
				node*temp=n;
				head=n->next;
				free(temp);
			}
		}
		void deleteEnd()
		{
			if(count()==0)
			cout<<"List Empty."<<endl;
			else
			{
				node*n=head;
				node*trace=n;
				while(n->next!=NULL)
				{
					trace=n;
					n=n->next;
				}
				node*temp=n;
				trace->next=NULL;
				free(temp);
			}
		}
		void deleteMiddle(int pos)
		{
			if(count()==0)
			cout<<"List Empty."<<endl;
			else if(count()==1||pos==1)
			{
				deleteBegin();
			}else if(pos==count())
			{
				deleteEnd();
			}else if(pos>count()||pos<1)
			{
				cout<<"Please Enter A Valid Position."<<endl;
			}else
			{
				int i=0;
				node*n=head;
				node*temp=new node();
				while(i!=pos-1)
				{
					i++;
					temp=n;
					n=n->next;
				}
				temp->next=n->next;
				free(n);
			}
		}
		void display()
		{
			node*check=head;
			if(head==NULL)
			cout<<"There Are No Nodes."<<endl;
			else
			{
				while(check!=NULL)
				{
					cout<<check->data<<"  ";
					check=check->next;
				}
				cout<<endl;
			}
		}
		int count()
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(n->next==NULL)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return c;
		}
		node* indexer(int x)
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(c==x)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return n;
		}
		void bubbleSort()
		{
			int i,j,temp;
			for(i=1;i<count();i++)
			{
				for(j=1;j<count();j++)
				{
					if(indexer(j)->data>indexer(j+1)->data)
					{
						swap(indexer(j)->data,indexer(j+1)->data);
					}
				}
			}
		}
		void combSort()
		{
			int i,gap=count();
			bool flag=true;
			while(gap!=1||flag==true) 
			{
    			gap=(gap*10)/13;
     			if(gap<1)
        	 	{
        	 		gap=1;
				}
      			flag = false;
      			for(i=1;i<count()-gap+1;i++)
				{
        	 		if(indexer(i)->data>indexer(i+gap)->data)
					{
        	   			swap(indexer(i)->data,indexer(i+gap)->data);
        	  			flag = true;
        	 		}
      			}
   			}
		}
		void insertionSort()
		{
			int i,key,j;  
   			for(i=1;i<count()+1;i++) 
   			{  
      			key=indexer(i)->data;
      			j=i-1;
       			while(j>=1 &&indexer(j)->data>key) 
        		{  
           			indexer(j+1)->data=indexer(j)->data;  
           			j=j-1;  
        		}  
        		indexer(j+1)->data=key;  
    		}
		}
		void selectionSort()  
		{
   			int i,j,min;
    		for (i=0;i<count();i++) 
    		
    		{  
        		min=i;
        		for (j=i+1;j<count()+1;j++)  
        		if(indexer(j)->data<indexer(min)->data) 
        		{
        			min=j;
				}
        		swap(indexer(min)->data,indexer(i)->data);  
    		}  
		}
};
int main()
{
	lister l;
	l.addEnd(50);
	l.addEnd(40);
	l.addEnd(30);
	l.addEnd(20);
	l.addEnd(10);
	l.display();
//	l.bubbleSort();
//	l.combSort();
	l.insertionSort();
//	l.selectionSort();
	l.display();
	//50 20 10 30 40
	return 0;
}
