#include<bits/stdc++.h>
using namespace std;
void bubbleSort(int [],int);
void display(int [],int);
int main()
{
	int size=10;
	int arr[size]={10,9,8,7,6,5,4,3,2,1};
	bubbleSort(arr,size);
	display(arr,size);
	return 0;
}
void display(int arr[],int size)
{
	int i;
	for(i=0;i<size;i++)
	{
		cout<<arr[i]<<" ";
	}
}
void bubbleSort(int arr[],int size)
		{  
   			int i,j,temp;
			for(i=0;i<size;i++)
			{
				for(j=0;j<size-i;j++)
				{
					if(arr[j]>arr[j+1])
					{
						swap(arr[j],arr[j+1]);
					}
				}
			}
		}
