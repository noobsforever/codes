#include <bits/stdc++.h>
using namespace std;
void heapify(int[],int[], int n, int i);
void heapSort(int[],int[], int n);
int deleter(int[],int[],int);
int height(int[],int[],int);
int main(){
    int arr[]={20,10,15,30,50,40,60,90};
    int arr2[]={1,2,3,10,5,6,7,8};
    int size=sizeof(arr)/sizeof(int);
    cout<<"Before: "<<endl;
    for(int i=0;i<size;i++){
        cout<<arr[i]<<" ";
    }
    heapSort(arr,arr2,size);
    cout<<"\nAfter: "<<endl;
    for(int i=0;i<size;i++){//size-1 as deleter used
        cout<<arr[i]<<" ";
    }
    cout<<"\nPriorities: "<<endl;
    for(int i=0;i<size;i++){//size-1 as deleter used
        cout<<arr2[i]<<" ";
    }
    size=deleter(arr,arr2,size);
    cout<<"\nAfter Delete: "<<endl;
    for(int i=0;i<size;i++){//size-1 as deleter used
        cout<<arr[i]<<" ";
    }
    cout<<"\nPriorities: "<<endl;
    for(int i=0;i<size;i++){//size-1 as deleter used
        cout<<arr2[i]<<" ";
    }
//    cout<<endl<<endl<<"Height Of Heap = "<<height(arr,arr2,size);
};

void heapify(int arr[],int arr2[],int n,int i){
    int max=i;
    int l=2*i+1;//15
    int r=2*i+2;//16
    if(l<n && arr2[l]<arr2[max]){
        max=l;
    }
    if(r<n && arr2[r]<arr2[max]){
        max=r;
    }
    if(max!=i){
        swap(arr[i],arr[max]);
        swap(arr2[i],arr2[max]);
        heapify(arr,arr2,n,max);
    }
}
void heapSort(int arr[],int arr2[],int n){
    for(int i=n-1;i>=0;i--){
        heapify(arr,arr2,n,i);
    }
    for(int i=n-1;i>=0;i--){
        swap(arr[0],arr[i]);
        swap(arr2[0],arr2[i]);
        heapify(arr,arr2,i,0);
    }
}
int deleter(int arr[],int arr2[],int n)
{
	heapSort(arr,arr2,n);
	swap(arr[0],arr[n-1]);
	swap(arr2[0],arr2[n-1]);
	heapSort(arr,arr2,n-1);
	return n-1;//returns new size
}
int height(int arr[],int arr2[],int n)
{
	heapSort(arr,arr2,n);
	if(n==1)
	{
		return 1;
	}else
	{
		return floor(log2(n))+1;
	}
}
