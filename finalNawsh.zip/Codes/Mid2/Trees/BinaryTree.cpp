#include<bits/stdc++.h>
using namespace std;

class node
{
	public:
	int val;
	node*left;
	node*right;	
	node()
	{
		left=NULL;
		right=NULL;
	}
};
class tree
{
	public:
	node* root;
	node *lastnode, *parentOfLastnode; 
	tree()
	{
		root=NULL;
	}
	void insert(int a)
	{
		if(root!=NULL)
		{
			insert2(a,root);
		}else
		{
			root=new node();
			root->val=a;
		}
	}
	private:
	void insert2(int a,node*leaf)//This will be called by insert
	{
		if(leaf->left==NULL)
		{
			leaf->left=new node;
			leaf->left->val=a;
		}else if(leaf->right==NULL)
		{
			leaf->right=new node;
			leaf->right->val=a;
		}
		else
		{
			insert2(a,leaf->left);//Will Go Down Heirarchy
		}
	}
	public:
	void inOrder(){inOrder(root);}//Main calls inOrder and through this, recursion starts
	void preOrder(){preOrder(root);}
	void postOrder(){postOrder(root);}
	void inOrder(node*leaf)
	{
		if(leaf!=NULL)
		{
			inOrder(leaf->left);
			cout<<leaf->val<<" ";
			inOrder(leaf->right);
		}	
	}
	void preOrder(node*leaf)
	{
		if(leaf!=NULL)
		{
			cout<<leaf->val<<" ";
			preOrder(leaf->left);
			preOrder(leaf->right);
		}
	}
	void postOrder(node*leaf)
	{
		if(leaf!=NULL)
		{
			postOrder(leaf->left);
			postOrder(leaf->right);
			cout<<leaf->val<<" ";
		}
	}
	int count(){count(root);}
	int count(node*leaf)
	{
		if(leaf==NULL)
		{
			return 0;
		}else
		{
			int c=1;
			c+=count(leaf->right);
			c+=count(leaf->left);
			return c;
		}
	}
	int maxDepth(){maxDepth(root);}
	int maxDepth(node* leaf) 
	{  
    if (leaf == NULL)  
        return -1;  
    else
    {  
        int lDepth = maxDepth(leaf->left);  
        int rDepth = maxDepth(leaf->right);  
        if (lDepth > rDepth)  
            return(lDepth+1);  
        else return(rDepth+1);  
    }
	}
	
	void getLastnodeAndItsParent(node *root, int level, node *parent) 
	{ 
	    if (root == NULL) 
	        return; 
	    if (level == 1) 
	    { 
	        lastnode = root; 
	        parentOfLastnode = parent;
	    } 
	    getLastnodeAndItsParent(root->left, level - 1, root); 
	    getLastnodeAndItsParent(root->right, level - 1, root); 
	}
	void deleteLastnode() 
	{ 
	    int levelOfLastnode = maxDepth()+1; 
	    getLastnodeAndItsParent(root, levelOfLastnode, NULL); 
	  
	    if (lastnode && parentOfLastnode) 
	    { 
	        if (parentOfLastnode->right) 
	            parentOfLastnode->right=NULL; 
	        else
	            parentOfLastnode->left=NULL;
	    } 
	    else
	        cout << "Empty Tree\n"; 
	}
};
int main()
{
	tree t;//Equal Or Greater Goes On Right In SearchTree
	t.insert(15);//							15
	t.insert(10);//						10		20
	t.insert(20);//					30		50
	t.insert(30);//				40		460
	t.insert(50);//			2		1
	t.insert(40);//		1
	t.insert(460);
	t.insert(2);
	t.insert(1);
	t.insert(1);
	cout<<t.maxDepth()<<endl;;
	t.deleteLastnode();
	t.deleteLastnode();
	cout<<t.maxDepth();
	return 0;
}







