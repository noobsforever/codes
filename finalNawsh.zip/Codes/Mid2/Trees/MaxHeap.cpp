#include <bits/stdc++.h>
using namespace std;
void heapify(int arr[], int n, int i);
void heapSort(int arr[], int n);
int deleter(int[],int);
int height(int[],int);
int main(){
    int arr[]={20,10,15,30,50,40,60,90};
    int size=sizeof(arr)/sizeof(int);
    cout<<"Before: "<<endl;
    for(int i=0;i<size;i++){
        cout<<arr[i]<<" ";
    }
    heapSort(arr,size);
    size=deleter(arr,size);
    cout<<endl<<endl<<"Deleted:"<<arr[size]<<endl;
    cout<<"\nAfter: "<<endl;
    for(int i=0;i<size;i++){//size-1 as deleter used
        cout<<arr[i]<<" ";
    }
    cout<<endl<<endl<<"Height Of Heap = "<<height(arr,size);
};

void heapify(int arr[],int n,int i){
    int max=i;
    int l=2*i+1;//15
    int r=2*i+2;//16
    if(l<n && arr[l]<arr[max]){
        max=l;
    }
    if(r<n && arr[r]<arr[max]){
        max=r;
    }
    if(max!=i){
        swap(arr[i],arr[max]);
        heapify(arr,n,max);
    }
}
void heapSort(int arr[],int n){
    for(int i=n-1;i>=0;i--){
        heapify(arr,n,i);
    }
    for(int i=n-1;i>=0;i--){
        swap(arr[0],arr[i]);
        heapify(arr,i,0);
    }
}
int deleter(int arr[],int n)
{
	heapSort(arr,n);
	swap(arr[0],arr[n-1]);
	heapSort(arr,n-1);
	return n-1;//returns new size
}
int height(int arr[],int n)
{
	heapSort(arr,n);
	if(n==1)
	{
		return 1;
	}else
	{
		return floor(log2(n))+1;
	}
}
