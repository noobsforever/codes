using namespace std;
#include<bits/stdc++.h>
class node
{
	public:
		char data;
		node* next;
};

class Stack
{
	public:
		node* head;
		Stack()
		{
			head=NULL;
		}
		void push(int a)
		{
			node* temp=new node();
			if(head==NULL)
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}else
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}
		}
		bool isEmpty()
		{
			if(count()==0)
			{
				return true;
			}else 
			return false;
		}
		void pop()
		{
			node* n=head;
			node*temp=n;
			head=n->next;
			free(temp);
		}
		int count()
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(n->next==NULL)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return c;
		}
};
bool isBalanced(string,Stack);
int main()
{
	Stack l;
	string brackets="{()}[]";
	bool value=isBalanced(brackets,l);
	if(value)
	{
		cout<<brackets<<" is a balanced expression."<<endl;
	}else
	{
		cout<<brackets<<" is an unbalanced expression."<<endl;
	}
	return 0;
}

bool isBalanced(string a,Stack l)
{
	int i;
	for(i=0;i<a.length();i++)
	{
		if(a[i]=='['||a[i]=='{'||a[i]=='(')
		{
			l.push(a[i]);
			continue;
		}
		if(l.isEmpty())
		{
			return false;
		}
		if(a[i]==')')
		{
			if(l.head->data=='{'||l.head->data=='[')
			{
				return false;
			}
			l.pop();
		}
		else if(a[i]=='}')
		{
			if(l.head->data=='('||l.head->data=='[')
			{
				return false;
			}
			l.pop();
		}
		else if(a[i]==']')
		{
			if(l.head->data=='('||l.head->data=='{')
			{
				return false;
			}
			l.pop();
		}
	}
	if(l.isEmpty())
	{
		return true;
	}else return false;
}



