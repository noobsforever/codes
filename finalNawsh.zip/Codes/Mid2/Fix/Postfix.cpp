using namespace std;
#include<bits/stdc++.h>
class node
{
	public:
		char data;
		node* next;
};

class Stack
{
	public:
		node* head;
		Stack()
		{
			head=NULL;
		}
		void push(int a)
		{
			node* temp=new node();
			if(head==NULL)
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}else
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}
		}
		bool isEmpty()
		{
			if(count()==0)
			{
				return true;
			}else 
			return false;
		}
		void pop()
		{
			node* n=head;
			node*temp=n;
			head=n->next;
			free(temp);
		}
		int count()
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(n->next==NULL)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return c;
		}
};
int precedence(char a);
bool isOperator(char a);
bool isOperand(char a);
void infixToPostfix(Stack,string);

int main()
{
	Stack l;
	string infix="x+((x*y+x)/y)";
	infixToPostfix(l,infix);
	return 0;
}

bool isOperator(char a)
{
	if(a=='+'||a=='-'||a=='*'||a=='/'||a=='%'||a=='^')
	return 1;
	else return 0;
}
bool isOperand(char a)
{
	if((a>='a'&&a<='z')||(a>='A'&&a<='Z'))
	return 1;
	else return 0;
}
int precedence(char a)
{
	if(a=='^')
	return 3;
	else if(a=='*'||a=='/'||a=='%')
	return 2;
	else if(a=='+'||a=='-')
	return 1;
	else return 0;
}

void infixToPostfix(Stack l,string infix)
{
	int i;
	string postfix;
		l.push('X');//test variable
		for(i=0;i<infix.length();i++)
		{
			if(isOperand(infix[i]))
			{
				postfix+=infix[i];
			}else if(infix[i]=='(')
			{
				l.push(infix[i]);
			}else if(infix[i]==')')
			{
				while(l.head->data!='X'&&l.head->data!='(')
				{
					postfix+=l.head->data;
					l.pop();
				}
				if(l.head->data=='(')
				{
					l.pop();
				}
			}else
			{
				while(l.head->data!='X'&&precedence(infix[i])<=precedence(l.head->data))
				{
					postfix+=l.head->data;
					l.pop();
				}
				l.push(infix[i]);
			}
		}
		{
			while(l.head->data!='X')
			{
				postfix+=l.head->data;
				l.pop();
			}
		}
		cout<<postfix;
}
