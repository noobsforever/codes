#include<bits/stdc++.h>
using namespace std;

class node
{
	public:
	int val;
	node*left;
	node*right;	
	node()
	{
		left=NULL;
		right=NULL;
	}
};
class tree
{
	public:
	node* root;
	tree()
	{
		root=NULL;
	}
	void insert(int a)
	{
		if(root!=NULL)
		{
			insert2(a,root);
		}else
		{
			root=new node();
			root->val=a;
		}
	}
	private:
	void insert2(int a,node*leaf)//This will be called by insert
	{
		if(leaf->left==NULL)
		{
			leaf->left=new node;
			leaf->left->val=a;
		}else if(leaf->right==NULL)
		{
			leaf->right=new node;
			leaf->right->val=a;
		}
		else
		{
			insert2(a,leaf->left);//Will Go Down Heirarchy
		}
	}
	public:
	void inOrder(){inOrder(root);}//Main calls inOrder and through this, recursion starts
	void preOrder(){preOrder(root);}
	void postOrder(){postOrder(root);}
	private:
	void inOrder(node*leaf)
	{
		if(leaf!=NULL)
		{
			inOrder(leaf->left);
			cout<<leaf->val<<" ";
			inOrder(leaf->right);
		}	
	}
	void preOrder(node*leaf)
	{
		if(leaf!=NULL)
		{
			cout<<leaf->val<<" ";
			preOrder(leaf->left);
			preOrder(leaf->right);
		}
	}
	void postOrder(node*leaf)
	{
		if(leaf!=NULL)
		{
			postOrder(leaf->left);
			postOrder(leaf->right);
			cout<<leaf->val<<" ";
		}
	}
};
int main()
{
	tree t;//Equal Or Greater Goes On Right In SearchTree
	t.insert(15);
	t.insert(10);
	t.insert(20);
	t.insert(7);
	t.inOrder();
	return 0;
}







