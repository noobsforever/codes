#include <bits/stdc++.h>
using namespace std;
	class student 
	{
   private:
      string name;
      int* age;
   public:
   	student(string name="NULL",int val=0)
   	{
   		age=new int;
		*age=val;
		this->name=name;	
	}
   	student(const student &obj)
   	{
   		cout<<"DEEP COPY"<<endl;
   		name=obj.name;
   		age=new int;
   		*age=*obj.age;
	}
	student& operator =(const student &obj)
	{
		cout<<"OPERATOR"<<endl;
		if(this!=&obj)
		{
			name=obj.name;
			*age=*obj.age;
		}
		return *this;
	}
	void display()
	{
		cout<<"NAME: "<<name<<endl;
		cout<<"AGE: "<<*age<<endl;
	}
	~student()
	{
		cout<<"DESTRUCTOR"<<endl;
		delete age;
		age=NULL;
	}
};

int main() 
{
	student s1("hamza",20);
	s1.display();
	student s2;
	s2=s1;
	s2.display();
	student s3(s2);
	s3.display();
	student s4=s3;
	s4.display();
   return 0;
}
