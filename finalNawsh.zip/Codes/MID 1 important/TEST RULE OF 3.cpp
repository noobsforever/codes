#include<iostream>
using namespace std;
class car
{
	string name;
	int *num;
	public:
		car(string name="NULL",int value=0)
		{
			this->name=name;
			num=new int;
			*num=value;
		}
		car(const car &c)
		{
			cout<<"constructor"<<endl;
			this->name=c.name;
			num=new int;
			*num=*c.num;
		}
		car& operator =(const car &c)
		{
			cout<<"OPERATOR"<<endl;
			if(this!=&c)
			{
				this->name=c.name;
				num=new int;
				*num=*c.num;
			}
			return *this;
		}
		~car()
		{
			delete num;
		}
		void output()
		{
			cout<<"NAME: "<<name<<endl;
			cout<<"NUM: "<<*num<<endl;
		}
};
int main()
{
	car c1("matsuda",19);
	c1.output();
	car c2=c1;//constructor
	c2.output();
	car c3;
	c3=c1;//operator
	c3.output();
	car c4(c3);//constructor
	c4.output();
	return 0;
}

