#include <stdio.h>
#include <iostream>
using namespace std;
class Node{
    public:
    int value;
    Node *next;
};

class CircularLinkedList{
    public:
    Node *head;
    Node *tail;

    CircularLinkedList(){
        head=NULL;
        tail=NULL;
    }

    void AppendEnd(int val){
        Node *temp=new Node;
        temp->next=head;
        temp->value=val;
        if(head==NULL){
            head=temp;
            tail=temp;
        }
        else{
            tail->next=temp;
            tail=temp;
        }
    }

    void AppendStart(int val){
        Node *temp=new Node;
        temp->next=head;
        temp->value=val;
        if(head==NULL){
            head=temp;
            tail=temp;
        }
        else{
            head=temp;
            tail->next=head;
        }
    }

    void Display(){
        Node *temp= new Node;
        temp=head;
        while(1){
            cout<<temp->value<<endl;
            temp=temp->next;
            if(temp->next==head){
                cout<<temp->value<<endl;
                break;
            }
        }
    }
    Node *nodeAtIndex(int index){
        Node *temp;
        temp=head;
        int count=0;
        while(1){
            if(count==index){
                return temp;
            }
            temp=temp->next;
            count++;
        }
    }

    int elementCount(){
        Node *temp=head;
        int count=0;
        while(1){
            if(temp->next==head){
                return count+1;
            }
            temp=temp->next;
            count++;
        }
    }

    

    // void selectionSort(){
    //     Node *track;
    //     int i,j,trackIndex=0,minIndex,temp;
    //     Node *min;
    //     bool minFound=false;
    //     min=nodeAtIndex(0);
    //     for(i=0;i<elementCount();i++){
    //         minFound=false;
    //         for(j=trackIndex;j<elementCount();j++){
    //             if()
    //         }
    //     }
    // }

    void insertionSort(){
        
        Node *track,temp;
        int i,j;
        for(i=1;i<elementCount();i++){
            track=nodeAtIndex(i);
            cout<<"Track: "<<track->value<<endl;
            j=i-1;
            while(j>=0 && nodeAtIndex(j)->value>track->value){
                cout<<"j+1: "<<nodeAtIndex(j+1)->value<<endl;
                cout<<"j: "<<nodeAtIndex(j)->value<<endl;
                nodeAtIndex(j+1)->value=nodeAtIndex(j)->value;
                j--;
            }
            cout<<"Track outside loop"<<track->value<<endl;
            temp=nodeAtIndex(j+1);
            temp=track;
        }
        cout<<"\n\n"<<endl;
        for(i=0;i<elementCount();i++){
            cout<<nodeAtIndex(i)->value<<endl;
        }
    }
   
};
int main(){
    CircularLinkedList list;
    list.AppendEnd(9);
    list.AppendEnd(5);
    list.AppendEnd(1);
    list.AppendEnd(0);
    list.AppendEnd(4);
    list.AppendEnd(2);
    list.AppendEnd(3);
    
    list.insertionSort();
    
   
    
    return 0;
}
