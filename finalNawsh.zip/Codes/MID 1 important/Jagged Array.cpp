#include<bits/stdc++.h>
using namespace std;
int main()
{
	int rows,i,j,index,temp;
	vector<vector <int> > arr;
	cout<<"Enter Number Of Rows: ";cin>>rows;
	for(i=0;i<rows;i++)
	{
		arr.push_back(vector<int>());
	}
	for(i=0;i<rows;i++)
	{
		cout<<"Enter Values, Press 0 To Stop."<<endl;
		cout<<"Values For Row "<<i<<" : ";
		while(1)
		{
			cin>>temp;
			if(temp==0)
			{
				break;
			}else
			{
				arr[i].push_back(temp);
			}
		}	
	}
	system("PAUSE");
	system("CLS");
	cout<<"OUTPUT: "<<endl<<endl;
	for(i=0;i<rows;i++)
	{
		cout<<i<<" | ";
		for(j=0;j<arr[i].size();j++)
		{
			cout<<arr[i][j]<<' ';
		}
		cout<<endl;
	}
	return 0;
}
