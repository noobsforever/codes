using namespace std;
#include<bits/stdc++.h>
class node
{
	public:
		int data;
		node* next;
};
class lister
{
	public:
		node* head;
		lister()
		{
			head=NULL;
		}
		void addBegin(int a)
		{
			node* temp=new node();
			if(head==NULL)
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}else
			{
				temp->data=a;
				temp->next=head;
				head=temp;
			}
		}
		void addEnd(int a)
		{
			node* n=head;
			if(head==NULL)
			{
				node* temp=new node();
				temp->data=a;
				temp->next=NULL;
				head=temp;
			}else
			{
				while(n->next!=NULL)
				{
					n=n->next;
				}
				node* temp=new node();
				temp->data=a;
				temp->next=NULL;
				n->next=temp;
			}
		}
		void addMiddle(int a,int pos)
		{
			if(count()==0)
			{
				addBegin(a);
				cout<<"List Empty, Added Node At Beginning."<<endl;
			}else if(pos<1||pos>count()+1)
			{
				cout<<"Please Enter A Valid Postion."<<endl;
			}else
			{
				if(pos==1)
				{
					addBegin(a);
				}else if(pos==count()+1)
				{
					addEnd(a);
				}else
				{
					int i=0;
					node*temp=new node();
					node*n=head;
					while(i!=pos-2)
					{
						cout<<"i="<<i<<" n="<<n->data<<endl;
						i++;
						n=n->next;
					}
					temp->data=a;
					temp->next=n->next;
					n->next=temp;
				}
			}
		}
		void deleteBegin()
		{
			if(count()==0)
			cout<<"List Empty."<<endl;
			else
			{
				node* n=head;
				node*temp=n;
				head=n->next;
				free(temp);
			}
		}
		void deleteEnd()
		{
			if(count()==0)
			cout<<"List Empty."<<endl;
			else
			{
				node*n=head;
				node*trace=n;
				while(n->next!=NULL)
				{
					trace=n;
					n=n->next;
				}
				node*temp=n;
				trace->next=NULL;
				free(temp);
			}
		}
		void deleteMiddle(int pos)
		{
			if(count()==0)
			cout<<"List Empty."<<endl;
			else if(count()==1||pos==1)
			{
				deleteBegin();
			}else if(pos==count())
			{
				deleteEnd();
			}else if(pos>count()||pos<1)
			{
				cout<<"Please Enter A Valid Position."<<endl;
			}else
			{
				int i=0;
				node*n=head;
				node*temp=new node();
				while(i!=pos-1)
				{
					i++;
					temp=n;
					n=n->next;
				}
				temp->next=n->next;
				free(n);
			}
		}
		void display()
		{
			node*check=head;
			if(head==NULL)
			cout<<"There Are No Nodes."<<endl;
			else
			{
				while(check!=NULL)
				{
					cout<<check->data<<"  ";
					check=check->next;
				}
				cout<<endl;
			}
		}
		int count()
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(n->next==NULL)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return c;
		}
};

int main()
{
	lister l;
	l.addMiddle(10,500);
	l.addBegin(20);
	l.addEnd(30);
	l.addMiddle(40,4);
	l.addMiddle(50,2);
	l.display();
	l.deleteMiddle(3);
	l.display();
	l.deleteMiddle(1);
	l.display();
	l.deleteMiddle(2);
	l.display();
	l.deleteMiddle(2);
	l.display();
	l.deleteMiddle(1);

	l.display();
	//20 50 10 30 40
	return 0;
}
