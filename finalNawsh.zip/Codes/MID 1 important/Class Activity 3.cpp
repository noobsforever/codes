using namespace std;
#include<bits/stdc++.h>
bool game(int [4][4],int);
bool check(int [4][4],int,int);
int main()
{
	int grid[4][4]=
	{
		{0,0,0,0},
		{0,0,0,0},
		{0,0,0,0},
		{0,0,0,0}
	};
	
	game(grid,0);
	int i,j;
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			cout<<grid[i][j];
		}
		cout<<endl;
	}
	return 0;
}

bool game(int grid[4][4],int col)
{
	int i;
	if(col==4)
	return true;

//For same row left check
	for(i=0;i<4;i++)
	{
		if(check(grid,i,col))
		{
			grid[i][col]=1;
			
			if(game(grid,col+1))//Next column recursive call
			return true;
			
			grid[i][col]=0;
		}
	}
	return false;//If no solution
	
}
bool check(int grid[4][4],int row,int col)
{
	int i,j;
	for(j=0;j<4;j++)
	{
		if(grid[row][j])
		return false;
	}
	
	for(int i=row,j=col;i>=0 && j>=0;i--,j--)//going top left
	{
		if(grid[i][j])
		return false;
	}
	
	for(int i=row,j=col;i<=3 && j>=0;i++,j--)//going bottom left
	{
		if(grid[i][j])
		return false;
	}
//	for(int i=row,j=col;i>=0 && j<=3;i--,j++)//going top right
//	{
//		if(grid[i][j])
//		return false;
//	}
//	for(int i=row,j=col;i<=3 && j<=3;i--,j++)//going bottom right
//	{
//		if(grid[i][j])
//		return false;
//	}
	
	return true;//else
}









