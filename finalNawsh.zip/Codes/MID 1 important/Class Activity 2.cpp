#include<bits/stdc++.h>
using namespace std;

class A
{
	int *arr;
	int size;
	//Rule of 3/5
	public:
	A(){}
	A(int *arr,int size)
	{
		this->size=size;
		this->arr=new int[size];
		std::copy(arr,arr+size,this->arr);
	}
	A(const A &o)
	{
		size=o.size;
		arr=new int[o.size];
		std::copy(o.arr,o.arr+o.size,arr);
	}
	A &operator =(const A& o)
	{
		size=o.size;
		arr=new int[o.size];
		std::copy(o.arr,o.arr+o.size,arr);
		return *this;
	}
	~A()
	{
		delete[]arr;
		arr=0;
	}
};
int main()
{
	int arr[]={1,2,3,4,5};
	A a(arr,5);
	A a2(a);//Crash Time, To Avoid, Remove Destructor Or Make Copy Constructor (line 17)
	A a3=a;//works fine as our copy constructor used
	
	A a4;
	a4=a;//Crashes as = operator used now we have to make an overloaded = wala
	return 0;
}
