using namespace std;
#include<iostream>
int main()
{
	char arr[50];
	int first=0;int last=49;
	int c,i;
	for(i=0;i<50;i++)
	{
		arr[i]='0';
	}
	while(1)
	{
		cout<<"1. Add Element At First Place."<<endl;
		cout<<"2. Add Element At Last Place."<<endl;
		cout<<"3. Display Array Elements."<<endl;
		cout<<"0. Exit."<<endl;
		cout<<"Choice: ";cin>>c;
		if(last==first)
		{
			cout<<"Array Full.";
			exit(0);
		}
		else if(c==1)
		{
			cout<<"Input: ";
			cin>>arr[first];
			first++;
		}else if(c==2)
		{
			cout<<"Input: ";
			cin>>arr[last];
			last--;
		}
		else if(c==3)
		{
			int i;
			for(i=0;i<50;i++)
			{
				cout<<arr[i];
			}
			cout<<endl;
		}
		else if(c==0)
		{
			int i;
			for(i=first+1;i<last;i++)
			{
				arr[i]='c';//Filling Characters Before Ending Program
			}
			exit(0);
		}
	}
}
