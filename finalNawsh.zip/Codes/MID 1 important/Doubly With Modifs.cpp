using namespace std;
#include<bits/stdc++.h>
class node
{
	public:
		int data;
		node* next;
		node* tail;
};
class lister
{
	public:
		node* head;
		lister()
		{
			head=NULL;
		}
		void addBegin(int a)
		{
			node* temp=new node();
			if(head==NULL)
			{
				temp->data=a;
				temp->next=NULL;
				temp->tail=NULL;
				head=temp;
			}else
			{
				temp->data=a;
				temp->next=head;
				temp->next->tail=temp;
				head=temp;
			}
		}
		void addEnd(int a)
		{
			node* n=head;
			if(head==NULL)
			{
				node* temp=new node();
				temp->data=a;
				temp->next=NULL;
				temp->tail=NULL;
				head=temp;
			}else
			{
				while(n->next!=NULL)
				{
					n=n->next;
				}
				node* temp=new node();
				temp->data=a;
				temp->next=NULL;
				n->next=temp;
				temp->tail=n;
			}
		}
		void addMiddle(int a,int pos)
		{
			if(count()==0)
			{
				addBegin(a);
				cout<<"List Empty, Added Node At Beginning."<<endl;
			}else if(pos<1||pos>count()+1)
			{
				cout<<"Please Enter A Valid Postion."<<endl;
			}else
			{
				if(pos==1)
				{
					addBegin(a);
				}else if(pos==count()+1)
				{
					addEnd(a);
				}else
				{
					int i=0;
					node*temp=new node();
					node*n=head;
					while(i!=pos-2)
					{
						cout<<"i="<<i<<" n="<<n->data<<endl;
						i++;
						n=n->next;
					}
					temp->data=a;
					temp->next=n->next;
					n->next->tail=temp;
					n->next=temp;
				}
			}
		}
		void deleteBegin()
		{
			if(count()==0)
			cout<<"List Empty."<<endl;
			else
			{
				node* n=head;
				node*temp=n;
				head=n->next;
				head->tail=NULL;
				free(temp);
			}
		}
		void display()
		{
			node*check=head;
			if(head==NULL)
			cout<<"There Are No Nodes."<<endl;
			else
			{
				while(check->next!=NULL)
				{
					check=check->next;
				}
				while(1)
				{
					if(check==NULL)
					break;
					else
					{
						cout<<check->data<<endl;
						check=check->tail;
					}
				}
				cout<<endl;
			}
		}
		int count()
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(n->next==NULL)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return c;
		}
		node* indexer(int x)
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(c==x)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return n;
		}
};

int main()
{
	lister l;
	int i,j,sum=7;//sum to find
	bool flag=0;
	l.addEnd(1);
	l.addEnd(2);
	l.addEnd(4);
	l.addEnd(5);
	l.addEnd(6);
	l.addEnd(8);
	l.addEnd(9);
	l.display();
//	int counter=l.count()+1;
//	i=1;j=counter-1;
//	while(1)
//	{
//		if(i>=j&&flag==0)
//		{
//			cout<<"NO PAIRS";
//			break;
//		}else if(i>=j&&flag==1)
//		{
//			break;
//		}
//		else if(((l.indexer(i)->data)+(l.indexer(j)->data))==sum)
//		{
//			flag=1;
//			cout<<"("<<l.indexer(i)->data<<","<<l.indexer(j)->data<<")  "<<endl;
//			i++;
//			if(i>counter-1)
//			{
//				i--;
//			}
//		}else if(((l.indexer(i)->data)+(l.indexer(j)->data))<sum)
//		{
//			i++;
//		}else if(((l.indexer(i)->data)+(l.indexer(j)->data))>sum)
//		{
//			j--;
//		}
//		else
//		{
//			i--;
//			j--;
//		}
//	}
	return 0;
}
