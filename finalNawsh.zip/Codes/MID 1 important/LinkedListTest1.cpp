using namespace std;
#include<bits/stdc++.h>

class lister
{
	int node;
	lister* nodeptr;
	public:
		lister(int x=0)
		{
			node=x;
			next=NULL;
		}
	void add(int x)
	{
		int i=0;
		lister * temp;
		temp=
		while(1)
		{
			if(next==NULL)
			break;
			else
			{
				
			}
		}
		cout<<i;
	}
};

int main()
{
	lister l(10);
	lister* head;
	head=&l;
	head->add(20);
	return 0;
}
