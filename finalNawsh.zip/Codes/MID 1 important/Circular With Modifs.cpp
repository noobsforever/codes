using namespace std;
#include<bits/stdc++.h>
class node
{
	public:
		int data;
		node* next;
};

class lister
{
	public:
		node* head;
		lister()
		{
			head=NULL;
		}
		void addBegin(int a)
		{
			node* temp=new node();
			if(head==NULL)
			{
				node* temp=new node();
				temp->data=a;
				head=temp;
				temp->next=head;
			}else
			{
				node*n;
				n=head;
				while(1)
				{
					if(n->next==head)
					break;
					else
					n=n->next;
				}
				node* temp=new node();
				temp->data=a;
				n->next=temp;
				temp->next=head;
				head=temp;
			}
		}
		void addEnd(int a)
		{
			node* n=head;
			if(head==NULL)
			{
				node* temp=new node();
				temp->data=a;
				head=temp;
				temp->next=head;
			}else
			{
				while(1)
				{
					if(n->next==head)
					break;
					else
					n=n->next;
				}
				node* temp=new node();
				temp->data=a;
				n->next=temp;
				temp->next=head;
			}
		}
		void addMiddle(int a,int pos)
		{
			if(count()==0)
			{
				addBegin(a);
				cout<<"List Empty, Added Node At Beginning."<<endl;
			}else if(pos<1||pos>count()+1)
			{
				cout<<"Please Enter A Valid Postion."<<endl;
			}else
			{
				if(pos==1)
				{
					addBegin(a);
				}else if(pos==count()+1)
				{
					addEnd(a);
				}else
				{
					int i=0;
					node*temp=new node();
					node*n=head;
					while(i!=pos-2)
					{
						i++;
						n=n->next;
					}
					temp->data=a;
					temp->next=n->next;
					n->next=temp;
				}
			}
		}
		void display()
		{
			node*check=head;
			if(head==NULL)
			cout<<"There Are No Nodes."<<endl;
			else
			{
				while(check->next!=head)
				{
					cout<<check->data<<"  ";
					check=check->next;
				}
				cout<<check->data<<"  ";
				cout<<endl;
			}
		}
		int count()
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(n->next==head)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
				c++;
			}
			return c;
		}
		node* indexer(int x)
		{
			node*n=head;
			int c=0;
			if(head!=NULL)
			{
				c=1;
				while(1)
				{
					if(c==x)
					break;
					else
					{
					 	c++;
						n=n->next;	
					}
				}
			}
			return n;
		}
};

int main()
{
	lister l;
	int value=5;//value to add
	l.addEnd(3);
	l.addEnd(7);
	l.addEnd(9);
	l.addEnd(11);
	int i=0;
	while(1)
	{
		if(i>l.count())
		{
			l.addEnd(value);
			break;
		}else
		{
			i++;
			if(l.indexer(i)->data>value)
			{
				l.addMiddle(value,i);
				break;
			}
		}
	}
	l.display();
	return 0;
}
