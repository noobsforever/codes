#include<bits/stdc++.h>
using namespace std;
class node
{
	public:
	int val;
	node*left;
	node*right;	
	node()
	{
		left=NULL;
		right=NULL;
	}
};
class tree
{
	public:
	node* root;
	tree()
	{
		root=NULL;
	}
	void insert(int a)
	{
		if(root!=NULL)
		{
			insert2(a,root);
		}else
		{
			root=new node();
			root->val=a;
		}
	}
	private:
	void insert2(int a,node*leaf)//This will be called by insert
	{
		if(a<leaf->val)
		{
			if(leaf->left==NULL)
			{
				leaf->left=new node;
				leaf->left->val=a;
			}else
			insert2(a,leaf->left);
		}
		else if(a>=leaf->val)
		{
			if(leaf->right==NULL)
			{
				leaf->right=new node;
				leaf->right->val=a;
			}else
			insert2(a,leaf->right);
		}
	}
	public:
	void search(int a)
	{
		if(binSearch(a,root)!=NULL)
		{
			cout<<"Value Found"<<endl;
		}else
		cout<<"Value Not Found"<<endl;
	}
	node* binSearch(int a,node*leaf)
	{
		if(leaf!=NULL)
		{
			if(a==leaf->val)
			{
				return leaf;
			}else if(a>=leaf->val)
			{
				return binSearch(a,leaf->right);
			}else if(a<leaf->val)
			{
				return binSearch(a,leaf->left);
			}
		}else return NULL;
	}
	int count(){count(root);}
	int count(node*leaf)
	{
		if(leaf==NULL)
		{
			return 0;
		}else
		{
			int c=1;
			c+=count(leaf->right);
			c+=count(leaf->left);
			return c;
		}
	}
	int height(){height(root);}
	int height(node*leaf)
	{
		if(leaf==NULL)
		{
			return 0;
		}else
		{
			int max=0;
		}
	}
};
int main()
{
	tree t;//Equal Or Greater Goes On Right In SearchTree
	t.insert(15);
	t.insert(10);
	t.insert(20);
	t.insert(7);
	cout<<t.count();
	return 0;
}














