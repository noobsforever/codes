using namespace std;
#include<iostream>
int CountPaths(int,int);
int SumOfDigits(int x);
int main()
{
	cout<<SumOfDigits(123);
}
int SumOfDigits(int x)
{
 if (x == 0)
 return 0;
 return (x % 10 + SumOfDigits(x / 10));
} 
//int CountPaths(int n, int TotalPaths)
//{
//	if(n==0)
//	return TotalPaths;
//	else if (n==1)
//	return TotalPaths + 1;
//	else if (n==2)
//	return (TotalPaths+2);
//	else if (n==3)
//	return CountPaths(n-2,TotalPaths)+CountPaths(n-1,TotalPaths);
// 	else
//	return CountPaths(n-4, TotalPaths)+
//	CountPaths(n-2,TotalPaths)+CountPaths(n-1, TotalPaths);
//}




