#include<bits/stdc++.h>
using namespace std;

class node
{
	public:
		int data;
		node* next;
};

class CircularList
{
	public:
	node* head;
	CircularList()
	{
		head=NULL;
	}
	void display()
	{
		node*n=head;
		if(head==NULL)
		{
			cout<<"List Empty."<<endl;
		}else
		{
			do{
				cout<<n->data<<" ";
				n=n->next;
			}while(n!=head);
		}
	}
	int count()
	{
		if(head==NULL)
		{
			return 0;
		}else
		{
			int i=0;
			node*n=head;
			while(1)
			{
				if(n->next==head)
				return i+1;
				else
				{
					i++;
					n=n->next;
				}
			}
		}
	}
	void addBegin(int a)
	{
		if(head==NULL)
		{
			node*temp=new node();
			head=temp;
			temp->data=a;
			temp->next=head;
		}else if(count()==1)
		{
			node*temp=new node();
			node*temp2=new node();
			temp=head;
			temp2->data=a;
			temp2->next=temp;
			temp->next=temp2;
			head=temp2;
		}else
		{
			node*temp2=new node();
			node*temp3=new node();
			temp3=head;
			while(temp3->next!=head)
			{
				temp3=temp3->next;
			}
			temp2->data=a;
			temp2->next=head;
			head=temp2;
			temp3->next=head;
		}
	}
	void addEnd(int a)
	{
		if(count()==0)
		addBegin(a);
		else
		{
			node*temp=head;
			node*temp2=new node();
			temp2->data=a;
			do
			{
				temp=temp->next;
			}while(temp->next!=head);
			temp2->next=head;
			temp->next=temp2;
		}
	}
	void addMiddle(int a,int b)
	{
		if(count()==0)
		{
			addBegin(a);
			cout<<"List Empty, Value Added At First Node."<<endl;
		}
		else if(b==1)
		addBegin(a);
		else if(b==count()+1)
		addEnd(a);
		else if(b<1||b>count()+2)
		cout<<"Please Enter A Valid Position."<<endl;
		else
		{
			int i=1;
			node*temp=new node();
			node*back=new node();
			node*temp3=new node();
			temp3->data=a;
			temp=head;
			while(1)
			{
				i++;
				back=temp;
				temp=temp->next;
				if(i==b)
				break;
			}
			temp3->next=temp;
			back->next=temp3;
		}
	}
	void deleteBegin()
	{
		if(count()==0)
		cout<<"List Empty."<<endl;
		else if(count()==1)
		{
			node*temp=head;
			free(temp);
			head=NULL;
		}
		else
		{
			node*temp=head->next;
			node*temp2=head;
			node*temp3=head;
			while(1)
			{
				if(temp2->next==head)
				break;
				else
				{
					temp2=temp2->next;
				}
			}
			delete temp3;
			head=temp;
			temp2->next=temp;
		}
	}
	void deleteEnd()
	{
		if(count()==0)
		cout<<"List Empty."<<endl;
		else if(count()==1)
		{
			node*temp=head;
			free(temp);
			head=NULL;
		}
		else
		{
			node*temp=head;
			node*temp2=head;
			node*temp3=new node();
			while(1)
			{
				if(temp2->next==head)
				break;
				else
				temp=temp2;
				temp2=temp2->next;
			}
			temp3=temp2;
			delete temp3;
			temp->next=head;
		}
	}
};
int main()
{
	CircularList l;
	l.addBegin(40);
	l.deleteEnd();
	l.deleteBegin();
	cout<<"COUNT="<<l.count()<<endl;
	l.display();
	return 0;
}






