#include<iostream>
using namespace std;
class node{
	public:
		int data;
		node *lchild,*rchild;
};

class queue
{
	node  *que[30];
 	int data, rear, front;
 	public:
 		queue()
 		{
 			rear = front = -1;
 		}
 		int Empty()
 		{
			 if(rear == front)
			 	return 1;
			 else
			 	return 0;
 		}
 		int Full()
		 {
			if(rear == 30)
				return 1;
			else
				return 0;
	 	}
 		void Add(node *x)
 		{
			if(Full())
		 		cout << "\n Queue Overfl ow";
		 	else
		 		rear++;
		 		que[rear] = x;
		}
		node  *Del()
		{
			node *x;
		 	if(Empty())
		 	{
		 		cout << "\n Queue is empty";
		 		//return -1;
		 	}
		 	else
		 	{
		 		front++;
		 		x = que[front];
		 		return(x);
		 	}
		}
};

class bst{
	node *root;
	public:
		int insert(int key){
			node *newnode,*tmp;

	newnode=new node;
	newnode->data=key;
	newnode->lchild=newnode->rchild=NULL;
	if(root==NULL){
		root=newnode;
		return 0;
		
	}
	tmp=root; 
	while(tmp!=NULL){
		if(tmp->data>key){
			if(tmp->lchild==NULL){
				tmp->lchild=newnode;
				return 0;
		}
		tmp=tmp->lchild;}
		else{
			
	 if(tmp->rchild==NULL){
			tmp->rchild=newnode;
			return 0;
			}		

tmp=tmp->rchild;}
	} 
}
void traversal(){
	queue q;
	node *temp;
	temp=root;
	while(1){
		cout<<temp->data;
	if(temp->lchild!=NULL){
	q.Add(temp->lchild); 
 
	}
		if(temp->rchild!=NULL){
			q.Add(temp->rchild);
		
		}
		if(q.Empty()){
		break;
		}
		temp=q.Del();
	}
}
};

main(){
	bst b;
	
	
	int i,k;
	for(i=0;i<6;i++){
		cout<<"enter key:";
		cin>>k;
		b.insert(k);
	}
	b.traversal();
}
