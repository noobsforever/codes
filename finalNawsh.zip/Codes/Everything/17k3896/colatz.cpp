#include<iostream>
using namespace std;
class colatz{
	private:
		int num;
	public:
		colatz(int n)
		{
			num=n;
		}
		colatz()
		{	
		}
		seq(int num)
		{
			if(num==1)
			{
				cout<<"series completed"<<endl;
			}
			else if(num==0)
			{
				cout<<"series terminated"<<endl;
			}
			else if(num%2==0)
			{
				num=num/2;
				cout<<num<<" ";
				seq(num);
			}
			else if(num%2!=0)
			{
				num=(3*num)+1;
				cout<<num<<" ";
				seq(num);
			}
			
		}
		
};
main()
{
	colatz a;
	colatz(6);
	a.seq(6);
}
