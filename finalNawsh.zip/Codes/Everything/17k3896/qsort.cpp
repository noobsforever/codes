#include<iostream>
using namespace std;
int quicksort(int arr[],int left,int right)
{
	int i=left;
	int j=right;
	int pivot=arr[(left+right)/2];
	while(i<=j)
	{
		while(arr[i]<pivot)
		i++;
		while(arr[j]>pivot)
		j--;
		if(i<=j)
		{
			swap(arr[i],arr[j]);
			i++;
			j--;
		}
	}
	if(left<j)
	quicksort(arr,left,j);
	if(right<i)
	{
		quicksort(arr,i,right);
	}
}

int main()
{
	int arr[10],n,i;
	cin>>n;
	for(i=0;i<n;i++)
	{
		cin>>arr[i];
	}
	quicksort(arr,0,n-1);
	
	for(i=0;i<n;i++)
	{
		cout<<arr[i]<<" ";
	}
}
