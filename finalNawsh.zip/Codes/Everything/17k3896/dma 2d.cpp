#include<iostream>
using namespace std;

int main()
{
	int size;
	int **ptr;
	int col=0;

	
	cout<<"size col:";
	cin>>size>>col;
	
	ptr = new int*[size];
//	cout<<"enter val"<<endl;
	for(int i=0;i<size;i++)
	{
		ptr[i] =new int[col];
	}
	cout<<"input"<<endl;
	for(int i=0;i<size;i++)
	{
		for(int j=0;j<col;j++)
		{
		cout<<"arr["<<i<<"]["<<j<<"]"<<endl;
		cin>>ptr[i][j];
		}
	}
	
	cout<<"entered val are"<<endl;
	for(int i=0;i<size;i++)
	{
		for(int j=0;j<col;j++)
		{
		cout<<ptr[i][j]<<"  ";
		}
		cout<<endl;
	}
	
	for(int i=0;i<size;i++)
	{
		delete [] ptr[i];
	}
	delete  [] ptr;
	
}

