#include<iostream>
using namespace std;
int top=-1;
int a[10];
void push(int x)
{
	top++;
	a[top]= x;
	
}
int pop()
{
	if(top==-1)
	{
		cout<<" ";
	}
	else top--;
	
}
int rev()
{
	
	for(int i=0;i<top;i++)
	{
		cout<<a[top]<<endl;
		cout<<pop()<<endl;
	}
}
int Top()
{
	return a[top];
}
int main()
{
	push(1);
	push(2);
	push(3);
	push(4);
	rev();//popping out returns the number in the reverse order since the stack is lifo. 
	
}
