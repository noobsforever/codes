#include<iostream>
using namespace std;

void even(int n){
	if(n<0||n>100)
	{	}
	else{	
	cout<<"n="<<n<<endl;
	even(n+1);
	return;
	}
	
}
int main()
{
	int a;
	cout<<"n:";
	cin>>a;
	even(a);
}
