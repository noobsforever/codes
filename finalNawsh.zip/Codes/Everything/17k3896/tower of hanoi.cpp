#include<iostream>
using namespace std;
void toh(int n,char s,char d,char a)
{
	if(n==1)
	{
	cout<<"Move Disk "<<n<<" from "<<s<<" to "<<d<<endl;
	}
	else {
	toh(n-1,s,a,d);
	cout<<"Move Disk "<<n<<" from "<<s<<" to "<<d<<endl;
	toh(n-1,a,d,s);	
}
}
int main()
{
	int n=3;
	toh(n,'A','C','B');
}
