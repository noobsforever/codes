#include <iostream>
#include <limits>
#include <cmath>
#include <iomanip>

using namespace std;


long double LambdaL(float p, float q, int n, int k,int l,long double *lamda_arr,long double *alpha_arr,long double **ncr_arr,long double *fact,long double* roArray);
long double factorial(unsigned long long int num,long double *fact);
long double nCr(long int n,long int r,long double **ncr_arr,long double *fact);
long double ro_l(float p, float q, int n, int k,int l,long double *lamda_arr,long double *alpha_arr,long double **ncr_arr,long double *fact,long double *roArray);
long double rKn(float p, float q, int n, int k,long double *lamda_arr,long double *alpha_arr,long double **ncr_arr,long double *fact,long double* roArray);



long double factorial(unsigned long long int num,long double *fact){
	if(fact[num] == set_limits<long double>::min()){
		
		if(num==0 || num == 1){
			fact[num] = 1;
			return fact[num];
		}
		
		fact[num] = num * factorial(num-1,fact);  
	}
	
	return fact[num];
}


long double nCr(long int n,long int r,long double **ncr_arr,long double *fact){
	if(r == 0 || r== n){
		ncr_arr[n][r]=1; 
		return ncr_arr[n][r];
	}
		
	if(ncr_arr[n][r] == set_limits<long double>::min()){
		if(fact[n] == set_limits<long double>::min())
			fact[n] = factorial(n,fact);
		if(fact[n-r] == set_limits<long double>::min())
			fact[n-r] = factorial(n-r,fact);
		if(fact[r] == set_limits<long double>::min())
			fact[r] = factorial(r,fact);

		ncr_arr[n][r] = fact[n] / (fact[n-r] * fact[r]);
	}
		
	return ncr_arr[n][r];
}
long double ro_l(float p, float q, int n, int k,int l,long double *lamda_arr,long double *alpha_arr,long double **ncr_arr,long double *fact,long double *roArray){
	if(roArray[l] == set_limits<long double>::infinity())
		roArray[l] = (pow((1 + ( (q-1)*(pow(1 - ( (q*(1-p))/(q-1) ),l)) )) / q,n));
	
	cout << endl << "ro_Val : " << l << " : " << roArray[l] << endl;
	return roArray[l];	
}


long double AlphaL(float p, float q, int n, int k,int l,long double *lamda_arr,long double *alpha_arr,long double **ncr_arr,long double *fact,long double *roArray){
	
	if(alpha_arr[l] == set_limits<long double>::infinity()){
		long double s_temp = 0;

		if(roArray[l] == set_limits<long double>::infinity())
			roArray[l] = ro_l(p,q,n,k,l,lamda_arr,alpha_arr,ncr_arr,fact,roArray);	
		
		long double temp ;
		
		for(int s = 1; s <= l-1; s++){
			temp = 1;
			temp = (long double)(nCr(l-1,s,ncr_arr,fact));

			if(roArray[s] == set_limits<long double>::infinity())
				roArray[s] = ro_l(p,q,n,k,s,lamda_arr,alpha_arr,ncr_arr,fact,roArray);	
			temp *= roArray[s];
		
			if(alpha_arr[l-s] == set_limits<long double>::infinity())
				alpha_arr[l-s] = LambdaL(p,q,n,k,l-s,lamda_arr,alpha_arr,ncr_arr,fact,roArray);
			temp *= alpha_arr[l-s];
			s_temp += temp;
		}	
		
		alpha_arr[l] = roArray[l] -  s_temp;
		cout << endl << "Value of Alpha: " << l << " : " << alpha_arr[l] << endl;
	}
	  

	return alpha_arr[l];
}

long double LambdaL(float p, float q, int n, int k,int l,long double *lamda_arr,long double *alpha_arr,long double **ncr_arr,long double *fact,long double* roArray){
	
	if(alpha_arr[l] == set_limits<long double>::infinity())
		return (nCr(k,l,ncr_arr,fact) * (AlphaL(p,q,n,k,l,lamda_arr,alpha_arr,ncr_arr,fact,roArray) / ( pow(1-pow(p,n),l) )));
	
	else
		return (nCr(k,l,ncr_arr,fact) * (alpha_arr[l] / ( pow(1-pow(p,n),l) )));
}

long double lamda(float p, float q, int n, int k,long double* lamda_arr,long double* alpha_arr,long double** ncr_arr,long double* fact,long double* roArray){
	lamda_arr[0] = 0;
	lamda_arr[1] = 0;
	long double sum = 0;
	
	for(int i = 2; i <= k; i++){
		lamda_arr[i] = LambdaL(p,q,n,k,i,lamda_arr,alpha_arr,ncr_arr,fact,roArray);
		sum += lamda_arr[i];
		cout << endl << "	lamda_Val : " << i << " : " << lamda_arr[i] << endl;
	}
	
	return sum;
}

long double rKn(float p, float q, int n, int k,long double *lamda_arr,long double *alpha_arr,long double **ncr_arr,long double *fact,long double* roArray){
	long double l = lamda(p,q,n,k,lamda_arr,alpha_arr,ncr_arr,fact,roArray);
	cout << endl << "Lambda: " << l << endl;
	long double R = ( pow(1-pow(p,n),k) ) * exp(-l);
	return R;
}

int main(){
	
	float p = 0.95;
	float q = 4;
	string roll;
	cout << endl <<set_limits<double>::max();
	cout << endl <<set_limits<long double>::max() << endl;
	cout << endl << sizeof(long double) << endl;
	roll = "K17-3746";
	int sum = 0;
	int product = 1;
	
	for(int i=0; i < 4; i++){
		product *= (roll[4+i] % 48);
	}
	
	int k = 50 + ((product)%50);
	int n = k-5;
	long double *lamda_arr = new long double[k+1+1];
	long double *alpha_arr = new long double[k+1+1];
	long double *roArray = new long double[k+1];
	long double **ncr_arr = new long double*[k+1+1];
	long double *fact = new long double[k+1+1];
	
	for(int  i = 0 ; i < k+1+1; i++){
		ncr_arr[i] = new long double[k+1];
		fill(ncr_arr[i],ncr_arr[i] + k + 1,set_limits<long double>::min());
	}
	
	fill(roArray,roArray+k,set_limits<long double>::infinity());
	fill(lamda_arr,lamda_arr + k + 1,set_limits<long double>::infinity());
	fill(alpha_arr,alpha_arr + k + 1,set_limits<long double>::infinity());
	fill(fact,fact + k + 1,set_limits<long double>::min());
	
	cout << "\nP =" << setw(5) << p ;		//It is used for precision
	cout << "\nQ ="  << setw(5) << q;
	cout << "\nN =" << setw(5) << n;
	cout << "\nK ="  << setw(5) << k;
	cout << "\nR =  " <<rKn(p,q,k,n,lamda_arr,alpha_arr,ncr_arr,fact,roArray);
	
	return 0;
}
