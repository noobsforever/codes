#include<iostream>
using namespace std;

class queue{
	private:
		int rear,front, a[5];
	public:
		queue()
		{
			rear=front=-1;
		}	
		void enqueue(int x)
		{
			if(rear==4)
			{
				cout<<"isfull";
			}
			if(front==-1)
			{
				front++;
			}
			else
			{
				rear++;
				a[rear]=x;
			}
			
		}
		void dequeue()
		{
			front++;
			cout<<"removed:"<<a[front];
		}
		void display()
		{
			for(int i=front;i<=rear;i++)
			{
				cout<<a[front]<<endl;
			}
		}
};
int main()
{
	
    queue q;
    q.enqueue(1);
    q.enqueue(1);
    q.enqueue(3);
    q.enqueue(4);
    //q.enqueue(1002);
//    q.dequeue();
//    q.dequeue();
    q.enqueue(5);
    //q.dequeue();
    //q.dequeue();
   // q.enqueue();
    
  //  q.display();
    
}
