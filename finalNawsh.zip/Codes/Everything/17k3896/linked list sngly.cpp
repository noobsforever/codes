#include<iostream>
using namespace std;
class node{
	public:
	int data;
	node *next;
	
};
class slist{
	public:
		int length;
		node *head;
		slist()
		{
			this->length=0;
			this->head=NULL;
			
		}
		~slist()
		{
			cout<<"list deleted";
		}
		void add(int data)
		{
			node * n=new node();
			n->data=data;
			n->next= this->head;
			this->head=n;
			this->length++;
			
		}
		void print()
		{
			node* head=this->head;
			int i=1;
			while(head)
			{
				cout<<i<<": "<<head->data<<endl;
				head=head->next;
				i++;
			}
		}
	
};
int main()
{
	slist* list=new slist();
	int n;
	for(int i=0;i<4;i++)
	{
		cout<<"enter data";
		cin>>n;
		list->add(n);
	}
	list->print();
}
