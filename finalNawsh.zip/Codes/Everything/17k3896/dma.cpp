#include<iostream>
using namespace std;

int main()
{
	int size;
	int *ptr;

	
	cout<<"size:";
	cin>>size;
	
	ptr=new int[size];
	cout<<"enter val"<<endl;
	for(int i=0;i<size;i++)
	{
		cin>>ptr[i];
	}
	cout<<"entered val are"<<endl;
	for(int i=0;i<size;i++)
	{
		cout<<ptr[i]<<endl;
	}
}
