#include<iostream>
#include <cstdlib>
#include<string.h>
using namespace std;
class atype{
	private:
		int col;
		int *dynamicarray;
	public:
		atype()
		{
			col=0;
			dynamicarray= new int[col];
		}
		atype(int n)
		{
			col=n;
			dynamicarray = new int [col];
		}
		~atype()
		{
			delete [] dynamicarray;
		}
		void insert()
		{
			for(int i=0;i<col;i++)
			{
				cin>> dynamicarray[i];
			}
		}
		int &operator [](int i)
		{
			if(i<0||i>=col)
			{
				cout<<"nope";
				exit(1);
			}
			return dynamicarray[i];
		}
		atype(const atype &rhs)
		{
			col=rhs.col;
			dynamicarray= new int [col];
			memcpy(dynamicarray,rhs.dynamicarray,sizeof (int)*col);
		}
		atype &operator=(const atype& rhs)
		{
			if(this==&rhs)
			return *this;
			
			delete [] dynamicarray;
			
			col= rhs.col;
			dynamicarray= new int [col];
			memcpy(dynaicarray,rhs.dynamicarray,sizeof(int)*col);
			return *this;
		}
		atype &operator !=(const atype &rhs)
		{
			for(int i=0;i<col;i++)
			{
				if(dynamicarray[i]==rhs.dynamicarray[i])
				{
					cout<<"unequal";
					break;
				}
			}
			
		}
		friend istream &operator >>(istream &input,const atype &array)
		{
			int c;
			c=array.col;
			for(int i=0;i<c;i++)
			{
				cin>>array.dynamicarray[i];
			}
			return input;
		}
		
};
int main()
{
	int z;
	cout<<"no. og cols";
	cin>>z;
	
	atype ob1(z);
	ob1.insert();
	cin>>ob1;
	atype ob2;
	ob2=ob1;
	atype ob3=ob1;
	cout<<ob1[1]<<endl;
	cout<<ob1[2]<<endl;
	cout<<ob3[2];
	
	ob1!=ob3;
	
}
