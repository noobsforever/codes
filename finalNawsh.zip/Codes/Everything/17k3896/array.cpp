#include <iostream>
#include <limits.h> // For INT_MIN
#define MAX_SIZE 1000     // Maximum array size 
using namespace std;
int main()
{
    int arr[MAX_SIZE], size, i;
    int max1, max2;

    cout<<"Enter size of the array (1-1000): ";
    cin>>size;

    cout<<"Enter elements in the array: ";
    for(i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    max1 = max2 = 0;

    for(i=0; i<size; i++)
    {
        if(arr[i] > max1)
        {
            max2 = max1;
            max1 = arr[i];
        }
        else if(arr[i] > max2 && arr[i] < max1)
        {
            
            max2 = arr[i];
        }
    }

    cout<<"First largest = "<<max1;
    cout<<"Second largest = "<< max2;

    return 0;
}
