#include<iostream>
using namespace std;
int main()
{
	int arr[3],temp;
	int i;
	for(i=0;i<4;i++)
	{
		cin>>arr[i];
	}
	for(i=1;i<3;i++)
	{
		temp=arr[i];
		for(int j=i-1;(j>=0&&arr[j]>temp);j--)
		{
			arr[j+1]=arr[j];
		
		}
			arr[j+1]=temp;
	}
	for(i=0;i<4;i++)
	{
		cout<<arr[i]<<" ";
	}
}

