#include <iostream>
using namespace std;
void quicksort(int arr[],int left,int right)
{
	int i,j,pivot;
	i=left;
	j=right;
	pivot=arr[(left+right)/2];
	
	while(i<=j)
	{
		while(arr[i]<pivot)
		i++;
		while(arr[j]>pivot)
		j--;
		if(i<=j)
		{
			swap(arr[i],arr[j]);
			i++;
			j--;
		}
	}
	if(left<j)
	{	
	quicksort(arr,left,j);
	}
	
	if(right<i){
	quicksort(arr,i,right);
	}
}
int main()
{
    int a[50],n,i;
    cout<<"How many elements?";
    cin>>n;
    cout<<"\nEnter array elements:";
    
    for(i=0;i<n;i++)
        cin>>a[i];
	quicksort(a,0,n-1);
    cout<<"\nArray after sorting:";
    
    for(i=0;i<n;i++)
        cout<<a[i]<<" ";
    
    return 0;        
}
