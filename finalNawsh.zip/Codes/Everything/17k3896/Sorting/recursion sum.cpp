#include<iostream>
using namespace std;
int func(int num)
{

	if(num!=0)
	{
	return num%10 + func(num/10);
		
	}
	else 
	return 0;
}
int main()
{
	int num;
	cin>>num;
	cout<<"sum="<< func(num);
}
