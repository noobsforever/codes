#include<iostream>
using namespace std;
int main()
{
	int arr[10];
	int i,j,temp;

	
	for(i=0;i<10;i++)
	{
		cin>>arr[i];
	}
	int gap=10;
	bool swap=true;

	while(gap!=1||swap==true)
	{
		if((gap/1.3)<1)
		{
			gap=1;
		}
		else gap=gap/1.3;
			
		swap=false;
		for(i=0;i<10-gap;i++)
		{
			if(arr[i]>arr[i+gap])
			{
			temp=arr[i];
			arr[i]=arr[i+gap];
			arr[i+gap]=arr[i];
			swap=true;
		}
		}
	}
		cout<<"sort"<<endl;
		for(i=0;i<10;i++)
	{
		cout<<arr[i]<<" ";
	}
	
}
