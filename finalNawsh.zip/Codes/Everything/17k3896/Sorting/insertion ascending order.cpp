#include<iostream>
using namespace std;
int main()
{
	int arr[3],temp;
	int i,j=0;
	for(i=0;i<4;i++)
	{
		cin>>arr[i];
	}
	for(i=1;i<3;i++)
	{
		temp=arr[i];
		j=i-1;
		while(j>=0&&arr[j]>temp)
		{
		arr[j+1]=arr[j];
		j--;
		}
		arr[j+1]=temp;
	}
	for(i=0;i<4;i++)
	{
		cout<<arr[i]<<" ";
	}
}
/*if(arr[i]>arr[i+1])
		{
			arr[i]=arr[j+1];
			j++;
		}*/
