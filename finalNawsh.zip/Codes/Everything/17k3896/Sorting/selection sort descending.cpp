#include<iostream>
using namespace std;
int main()
{
	//selection sort.
	int arr[5];
	int i,j,temp;
	for(i=0;i<5;i++)
	{
		cin>>arr[i];
	}
	for(i=0;i<5;i++)
	{
		for(j=i+1;j<5;j++)
		{
			if(i>=0&&arr[i]<arr[j])
			{
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
			}
		}
	}
			cout<<"sorted"<<endl;
	for(i=0;i<5;i++)
	{
		cout<<arr[i]<<"  ";
	}
}
