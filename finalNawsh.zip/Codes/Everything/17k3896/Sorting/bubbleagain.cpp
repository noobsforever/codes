#include<iostream>
using namespace std;
void bubble(int arr[],int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<(n-i-1);j++)
		{
			if(j>=0 && arr[i]>arr[j])
			{
				swap(arr[i],arr[j]);
			}
		}
	}
}
int main()
{
	int n;
	cout<<"enter the number of elements:";
	cin>> n;
	int arr[n];
	
	for(int i=0;i<n;i++)
	{
		cin>>arr[i];
	}
	
	bubble(arr,n);
	
	for(int i=0;i<n;i++)
	{
		cout<<arr[i]<<" ";
	}
	
}
