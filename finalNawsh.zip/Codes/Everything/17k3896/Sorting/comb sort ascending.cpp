#include<iostream>
using namespace std;
int main()
{
	int arr[10];
	int i,j,temp,gap;
		for(i=0;i<10;i++)
	{
		cin>>arr[i];
	}
	
	gap=10;
	bool wap=true;
	
	while(gap!=1 ||wap==true)
	{
		if((gap/1.3)<1)
		{
			gap=1;
		}
		else gap=gap/1.3;
		
		wap=false;
		for(i=0;i<10-gap;i++)
		{
			if(arr[i]<arr[i+gap])
			{
			swap(arr[i],arr[i+gap]);
			wap=true;
		}
		}
	}
/*while(gap!= 1 || wap == true)
	{
		if(gap/1.3 <1)
			gap = 1;
		else gap = gap/1.3;
		
		wap = false;
		for (int i = 0 ; i<size-gap; i++)
		{
			if(arr[i]>arr[i+gap])
				{
					temp = arr[i];
					arr[i] = arr[i+gap];
					arr[i+gap]= temp;
					wap = true;
				}
		}
		
	}*/
	cout<<"sort"<<endl;
		for(i=0;i<10;i++)
	{
		cout<<arr[i]<<" ";
	}
}
