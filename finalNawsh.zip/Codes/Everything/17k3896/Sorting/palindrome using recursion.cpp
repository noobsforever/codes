#include<iostream>
using namespace std;
int func(int arr[],int end,int begin)
{
	if(begin>=end)
	{
		return 1;
	}
	else if (arr[begin]==arr[end])
	{
		return func(arr,end-1,begin+1);
	}
	else return 0;
}
int main()
{
	int n;
	cin>>n;
	int arr[n];
	for (int i=0;i<n;i++)
	{
		cin>>arr[i];
	}
	if(func(arr,n-1,0)==1)
	{
		cout<<"palindrome";
	}
	else 
	cout<<"nope";
}
