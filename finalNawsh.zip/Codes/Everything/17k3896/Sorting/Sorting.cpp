#include <iostream>

using namespace std;
/****************************************************
INSERTION SORT
KEY GRADUALLY SHIFTS UP
EVERYTHING BEHIND KEY IS SORTED
KEY INCREMENTED
****************************************************/
void Print(int arr[], int size){
	cout<<endl;
	for(int i = 0; i<size; i++){
		cout<<arr[i]<<"\t";
	}
}


/*
key is one initially
then in a loop we check if the next element is sorted
and switch until we get sorted
*/
void InsertionSort(int arr[], int size){
	int i, key, j;
	for (i = 1; i<size; i++)
	{
		key = arr[i];	//KEY IS INDEX 1
		j=i-1;			//J IS INDEX I -1
		while(j>=0 && arr[j]>key){	//LOOP RUNS WHILE VALUE AT J INDEX IS GREATER THAN
									//KEY AND J IS GREATER OR EQUAL TO 0
			//Print(arr, size);
			arr[j+1] = arr[j]; //J IS JUST BEING SHIFTED UP
			j= j-1;
		}
		arr[j+1]= key;
	}
}

void selectionSort(int arr[], int size){
	int i, j, minI, temp;
	for(i = 0; i< size -1; i++){
		minI=i;
		for(j = i+1; j<size; j++){
			if(arr[j]<arr[minI])
				minI=j;
		}
		temp = arr[minI];
		arr[minI]=arr[i];
		arr[i]=arr[minI];
	}
}

void bubbleSort(int arr[], int size){
	int temp;
	for(int i = 0; i<size-1; i++){
		for(int j = 0; j< size -i-1; j++){
			if(arr[j]<arr[j+1])
				{
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1]= temp;
				}
		}
	}
}

void combSort(int arr[], int size){
	int gap;
	gap = size;
	bool swap = true;
	int temp;
	while(gap!= 1 || swap == true)
	{
		if(gap/1.3 <1)
			gap = 1;
		else gap = gap/1.3;
		
		swap = false;
		for (int i = 0 ; i<size-gap; i++)
		{
			if(arr[i]>arr[i+gap])
				{
					temp = arr[i];
					arr[i] = arr[i+gap];
					arr[i+gap]= temp;
					swap = true;
				}
		}
		
	}
}

void shellSort(int a[], int size){
	for(int gap= size/2; gap> 0; gap/=2){
		for(int i = gap; i<size; i++)
		{
			int temp = a[i];
			int j = i;
			for(j; j>=gap &&temp<a[j-gap]; j -= gap){
				a[j]= a[j-gap];
			}
				a[j] = temp;
		}
	}
}

void merge(int arr[], int left, int mid, int right){
	int k;
	int sizeL= mid - left +1;
	int sizeR = right - mid;
	int L[sizeL], R[sizeR];
	for(int i = 0; i<sizeL; i++)
		L[i] = arr[left + i];
	for(int i = 0; i<sizeR; i++)
		R[i] = arr[mid+i+1];
	
	int i = 0, j = 0;
	k=left;
	while(i<sizeL &&j<sizeR){
		if (L[i] <= R[j]) 
        { 
            arr[k] = L[i]; 
            i++; 
        } 
        else
        { 
            arr[k] = R[j]; 
            j++; 
        } 
        k++; 
	}
	while(i<sizeR)
	{
		arr[k] = L[i];
		k++;
		i++;
	}
	while (j<sizeL){
		arr[k] = R[j];
		k++;
		j++;
	}
}

void mergeSort(int arr[], int left, int right){
	if (left<right)
	{
		int mid = left+ (right-1)/2;
		mergeSort(arr, left, mid);
		mergeSort(arr, mid+1, right);
		merge(arr, left, mid, right);
	}
}

int partition(int arr[], int low, int high){
	int pivot = (arr[high]+ arr[low])/2;
	int i = low - 1, temp;
	for(int j = low; j<=high-1; j++)
	{
		if(arr[j]<=pivot)
		{
			i++;
			temp = arr[i];
			arr[i]= arr[j];
			arr[j] = temp;
		}
	}
	temp =arr[high];
	arr[high]= arr[i+1];
	arr[i+1]= high;
	return i+1;
}

void quickSort(int arr[], int lowI, int highI){
	if(lowI< highI){
		int partI= partition(arr, lowI, highI);
		quickSort(arr, lowI, partI- 1);
		quickSort(arr, (partI+1), highI);
	}
}

void countSort(int arr[], int size, int max){
	int output[size];
	int countArr[max+1], k=0;
	for (int i = 0; i<=max; i++)
		countArr[i]=0;
	
	for(int i=0; i<size; i++)
	{
		countArr[arr[i]]++;
		
	}
	
	for(int i =0; i< size; i++)
	{
		for(int j = 0; j<countArr[i]; j++)
		{
			output[k]=i;
			k++;
		}
	}
}


int main(){
	int A[6] = {6, 5, 4, 3, 2, 1};
	int X[6] = {6, 5, 4, 3, 2, 1};
	//InsertionSort(X, 6);
	countSort(X, 6, 6);
	Print(X, 6);
	return 0;
}
