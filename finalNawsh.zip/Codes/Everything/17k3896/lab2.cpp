#include<iostream>
using namespace std;
class student{
	public:
		string name,id;
		float gpa;
		student()
		{
			cout<<"enter name:";
			cin>>name;
			cout<<endl<<"enter id:";
			cin>>id;
			cout<<endl<<"enter gpa:";
			cin>>gpa;
			cout<<endl;
		}

};
int main()
{
	student *p;
	cout<<"enter the number of students:";
	int n;
	cin>>n;
	p= new student[n];
	for(int i=0;i<n;i++)
	{
		p[i];
	}
	
	//sorting of obj
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(p[i].gpa<p[j].gpa)
			{
				swap(p[i].gpa,p[j].gpa);
			}
		}
	}
	
	//print
	for(int i=0;i<n;i++)
	{
		cout<<"name:"<<p[i].name<<endl<<"id:"<<p[i].id<<endl;
		cout<<"gpa:"<<p[i].gpa<<endl;
	}
}
