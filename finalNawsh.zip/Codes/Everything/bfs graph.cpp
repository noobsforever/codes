void Graph :: BreadthFirstSearch(int i)
{
 int k, visited[max];
 queue Q;
 for(k = 1; k <= n; k++)
 visited[k] = 0;
 visited[i] = 1;
 Q.Add(i);
 while(!Q.IsEmpty())
 {
 j = Q.Delete();
 for(k = 1; k <= n; k++)
 {
 if(Adj_Matrix [j,k] && !visited[k])
 {
 Q.Add(k);
 visited[k] = 1;
 }
 }
 }
}

void Graph :: BFS(int v)
{
 Queue q;
 GraphNode* curr;
 visited[v] = true;
 cout << "\t" << headnodes[v]->vertex;
 q.addq(headnodes[v]);
 while(!q.emptyq())
 {
 curr = q.deleteq();
 curr = curr->next;
 while(curr ! = null)
 {
 if(!visited[curr->vertex - 1])
 {
 q.addq(headnodes[curr->vertex - 1]);
 cout << "\t" << curr->vertex;

 visited[curr->vertex - 1] = true;
 }
 curr = curr->next;
 }
 }
 return;
}
