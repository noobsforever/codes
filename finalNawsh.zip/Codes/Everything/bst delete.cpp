#include<iostream>
using namespace std;
class node{
	public:
int data;
node *lchild,*rchild;
};

class queue
{
node  *que[30];
 int data, rear, front;
 public:
 queue()
 {
 rear = front = -1;
 }
 int Empty()
 {
 if(rear == front)
 return 1;
 else
 return 0;
 }
 int Full() {
         if(rear==30)
          return 1;
  else
        return 0;
 }
 void Add(node *x){
 if(Full())
         cout << "\n Queue Overfl ow";
 else
     rear++;
         que[rear]=x;
 }
 node  *Del(){
node *x;
 if(Empty()){
       cout << "\n Queue is empty";

 }
 else{
 	      front++;
      x=que[front];
 return(x);
 }
 }
};


class bst{
node *root;
public:
int insert(int key){
	node *newnode,*tmp;

	newnode=new node;
	newnode->data=key;
	newnode->lchild=newnode->rchild=NULL;
	if(root==NULL){
		root=newnode;
		return 0;
		
	}
	tmp=root; 
	while(tmp!=NULL){
		if(tmp->data>key){
			if(tmp->lchild==NULL){
				tmp->lchild=newnode;
				return 0;
		}
		tmp=tmp->lchild;}
		else{
			
	 if(tmp->rchild==NULL){
			tmp->rchild=newnode;
			return 0;
			}		

tmp=tmp->rchild;}
	} 
}
void traversal(){
	queue q;
	node *temp;
	temp=root;
	while(1){
		cout<<temp->data;
	if(temp->lchild!=NULL){
	q.Add(temp->lchild); 
 
	}
		if(temp->rchild!=NULL){
			q.Add(temp->rchild);
		
		}
		if(q.Empty()){
		break;
		}
		temp=q.Del();
	}
}


node *del(int k){
	node *tmp,*par,*x;
tmp=root;
if(root==NULL){
	cout<<"tree is empty";
	return NULL;
}
else{
	par=tmp;
	while(tmp!=NULL){
		if(tmp->data==k){
			break;
		}
		else if(k<tmp->data){
			par=tmp;
			tmp=tmp->lchild;
		}
		else{
			par=tmp;
			tmp=tmp->rchild;
			
		}
		
	}
	if(tmp->rchild!=NULL&&tmp->lchild!=NULL){
		if(tmp!=root){
		
		par=tmp;
		x=tmp->rchild;
		while(tmp->lchild!=NULL){
			par=x;
			x=x->lchild;
		}
		tmp->data=x->data;
	
}
else{
	root=NULL;
	delete tmp;
	return root;
}
delete x;
}
else if(tmp->lchild==NULL&&tmp->rchild==NULL){
	if(tmp==root){
		if(par->lchild==tmp){
			par->lchild=NULL;
			
		}
		else{
		par->rchild=NULL;
		}
		delete tmp;
	}
	else{
		root=NULL;
		delete tmp;
		return root;
	}
}
else if(tmp->lchild!=NULL&&tmp->rchild==NULL){
	if(tmp!=root){
		if(par->lchild==tmp){
			par->lchild=tmp->lchild;
		}
		else{
			par->rchild=tmp->rchild;
		}
	}
	else{
		root=tmp->lchild;
		
	}
	delete tmp;
	return root;
}
else if(tmp->lchild==NULL&&tmp->rchild!=NULL){
	if(tmp!=root){
		if(par->rchild==tmp){
			par->rchild=tmp->rchild;
		}
		else{
			par->lchild=tmp->lchild;
		}
	}
	else{
		root=tmp->rchild;
		
	}
	delete tmp;
	return root;
}

}
}
};

main(){
	bst b;
	
	
	int i,k,t;
	for(i=0;i<6;i++){
		cout<<"enter data:";
		cin>>k;
		b.insert(k);
	}
	b.traversal();


		cout<<"\nenter the value to be deleted";
	cin>>t;
	b.del(t);
	cout<<endl;
	b.traversal();
}


BstNode *deleteNode(BstNode *root, int data)
{
    if (root == NULL)
        return root;
    else if (data < root->data)
        root->left = deleteNode(root->left, data);
    else if (data > root->data)
        root->right = deleteNode(root->right, data);
    else
    {
        if (root->left == NULL && root->right == NULL)
        {
            delete root;
            root = NULL;
        }
        else if (root->left == NULL)
        {
            BstNode *temp = root;
            root = root->right;
            delete temp;
        }
        else if (root->right == NULL)
        {
            BstNode *temp = root;
            root = root->left;
            delete temp;
        }
        else
        {
            BstNode *min = findMinNode(root->right);
            root->data = min->data;
            root->right = deleteNode(root->right, min->data);
        }
    }
    return root;
}
