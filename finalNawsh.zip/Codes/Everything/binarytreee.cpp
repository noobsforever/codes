#include<iostream>
using namespace std;
#define Max 50
class node{
	public:
	int data;
	node *lchild;
	node *rchild;
	
};
 class stack
{
	
 	public:
		node *stk[Max];

 		int data,top;
 		stack *S;
 	public:
 		stack()
 		{
 			top = -1;
		}
 		int IsEmpty()
 {
 if(top == -1)
 return 1;
 else
 return 0;
 }
 void Push(node *x)
 {
 stk[++top] = x;
 }
 node *Pop()
 {
 node *x;
 x = stk[top];
 --top;
 return(x);
 }
};
class queue
{
 node *que[Max];
 int data, rear, front;
 public:
 queue()
 {
 rear = -1;
 front = 0;
 }
 int Empty()
 {
 if(rear == front)
 return 1;
 else
 return 0;
 }
 int Full()
 {
 if(rear == Max)
 return 1;
 else
 return 0;
 }
 void Add(node *x)
 {
 if(Full())
 cout << "\n Queue Overfl ow";
 else
 que[++rear] = x;
 }
 node *Del(){
 

 
 node *x;
 if(Empty())
 {
 cout << "\n Queue is empty";
 //return -1;
 }
 else
 {
 x = que[front];
 ++front;
 return(x);
 }
 }
};

class binarytree{
	node *root,*tail,*tmp1;
	char ans;
	public:
		void create(){
			node *newnode;
			queue q;
			newnode=new node;
			cin>>newnode->data;
			newnode->lchild=NULL;
			newnode->rchild=NULL;
			root=newnode;
		
			tail=newnode;
			do{
			
			if(tail->lchild==NULL){
				
					newnode=new node;
			cin>>newnode->data;
			newnode->lchild=NULL;
			newnode->rchild=NULL;
				tail->lchild=newnode;
				q.Add(newnode);
				cout<<"do you want to enter more data?(y/n)";
				cin>>ans;
				if(ans=='n'){
					break;
				}
			}
			else if(tail->rchild==NULL){
					newnode=new node;
			cin>>newnode->data;
			newnode->lchild=NULL;
			newnode->rchild=NULL;
				tail->rchild=newnode;
				q.Add(newnode);
					cout<<"do you want to enter more data?(y/n)";
				cin>>ans;
				if(ans=='n'){
					break;
				}
			}
		
			else{
			tail=q.Del();
}
			}
			while(1);
		}
		void	 Preorder_Non_Recursive()
{

node *Tmp = root;
 stack S;
 while(1)
 {
 while(Tmp != NULL)
 // traverse left till left is null and push
 {
 S.Push(Tmp);
 cout << Tmp ->data;
 Tmp = Tmp->lchild;
 }
 if(S.IsEmpty()) {
 return;}
 //if stack is not empty then pop one and go to
 Tmp = S.Pop();
 Tmp = Tmp->rchild;
 // if stack is empty stop the process
 }
}
};
main(){
	binarytree b;
	b.create();
	b.Preorder_Non_Recursive();
}
	
