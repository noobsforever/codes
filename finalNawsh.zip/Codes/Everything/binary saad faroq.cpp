#include<iostream>
using namespace std;

class node{
	public:
		
		node *right;
		node *left;
		int data;
		
		node(int a)
		{
			data= a;
			right = left = NULL;
		}
		
		
		node(int a, node * right )
		{
			data= a;
			this->right = right;
			left = NULL;
		}
	
		node(node * left,int a )
		{
			data= a;
			right = NULL;
			this->left = left;
		}
		
		node(node * left,int a, node * right )
		{
			data= a;
			this->right = right;
			this->left = left;
		}
	
		


};


class list{
	public:
		node * head;
		node * last;
		int co;
		list()
		{
			co=0;
			last= head= NULL;
		}
		
		
		
		addhead(int n)
		{
			head= new node(n);
		}
		
		node * insert(int n, node* ptr)
		{
			
			if(head==NULL)
			{
				head=last = new node(n);
			}
			else
			{
				
				if(ptr==NULL)
				{
					ptr= new node(n);
					cout<<ptr->data<<" Is added"<<endl;
					cout<<endl;
				}
				else if(n>ptr->data)
				{
					cout<<"Right of= "<<ptr->data<<endl;
			
					
					ptr->right=insert(n, ptr->right);	
				}
				else if(n<ptr->data)
				{
					cout<<"left of= "<<ptr->data<<endl;
			
					ptr->left=insert(n,ptr->left);
				}
				
				
			
			}
			return ptr;		
		}
		
		
		display(node * ptr)
		{
			if(ptr!=NULL)
			{
				display(ptr->left);
				cout<<ptr->data<<" ";
				display(ptr->right);
				
				
			}
			
		}
		
		
		node * search(int n, node* ptr)
		{
				if(ptr->data==n)
				{
					cout<<n<<" found!"<<endl;
					return ptr;
				}
				else if(n>ptr->data)
				{
					
					search(n, ptr->right);	
				}
				else if(n<ptr->data)
				{
					search(n,ptr->left);
				}
				
				
			
			}
		
	
	
	    count(node * ptr)
	    {
	    	
	    	if(ptr!=NULL)
	    	{
	    		if(ptr->right==NULL||ptr->left == NULL)
	    		{
	    			co++;
				}
				
				count(ptr->left);
				count(ptr->right);
				
			}
	    	
	    	
	    	
		}
		
};



main()
{
	list *a = new list;
	
	a->addhead(5);
	a->insert(1,a->head);
	a->insert(3,a->head);
	a->insert(2,a->head);
	a->insert(4,a->head);
	
	a->insert(6,a->head);
	
	a->insert(8,a->head);
	
	a->insert(5,a->head);
	
	a->insert(9,a->head);
	
	a->display(a->head);
	cout<<endl;
	a->count(a->head);
	cout<<"Leaves= "<<a->co<<endl;
	node* ptr=a->search(8, a->head);
	//a->del(2, a->head);
	cout<<endl;
}
