#include<iostream>
#include<stack>
using namespace std;
class queue{
	stack<int> s1,s2;
	
	public:
	void enqueue(int n1){
		while(!s1.empty()){
			s2.push(s1.top());
			s1.pop();
		}
		s1.push(n1);
		while(!s2.empty()){
			s1.push(s2.top());
			s2.pop();
		}
	}
	int dequeue(){
		int x=s1.top();
		
		s1.pop();
		return x;
	}
	
};


int main(){
	queue q1;
	for(int i=0;i<5;i++){
		q1.enqueue(i+1);
	}
	for(int i=0;i<5;i++){
		cout<<q1.dequeue()<<" ";
	}
}
