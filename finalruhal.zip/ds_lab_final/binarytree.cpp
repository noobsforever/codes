#include<iostream>
#include<vector>
using namespace std;
class node{
    public:
    int val;
    node* l,*r;
};
class binarytree{
    node *root;
    vector<vector<int> > total;
    public:
    binarytree(){
        root=NULL;
        
    }
    
   void insert(int n){
       
        
       if(root==NULL){
            root=new node;
            root->val=n;
            root->l=NULL;
            root->r=NULL;
        }
        else{
        	
        	node*temp=new node;
        temp->r=NULL;
        temp->val=n;
        temp->l=NULL;
            insert_node(temp,root);
        }

        
    }
    void insert_node(node* temp,node* leaf){
        
        if(temp->val<leaf->val){
        	if(leaf->l==NULL){
        		leaf->l=temp;
			}
			else{
				insert_node(temp,leaf->l);
			}
		}
		else if(temp->val>=leaf->val){
			if(leaf->r==NULL){
				leaf->r=temp;
			}
			else{
				insert_node(temp,leaf->r);
			}
		}

    }
    node* getroot(){
        return root;
    }

    void in_order(node* leaf)
	{
		if(leaf != NULL)
		{
			in_order(leaf->l);
			cout << leaf->val << "\t";
			in_order(leaf->r);
		}
	}
	void deleteal(){
		deleteall(root);
	}
	
	bool isempty(){
		if(root==NULL){
			return true;
		}
		return false;
	}
	
	
   void  print(node *r, int gap)
{	if(isempty()){
	cout<<"\n\n\n\n\nempty";
	return;
}
    if (r == NULL)
    {	
        return;
    }
    else
    {
        gap += 10;
        print(r->r, gap);
        cout << endl;
        for (int i = 10; i < gap; i++)
        {
            cout << " ";
        }
        cout << r->val << "\n";
        print(r->l, gap);
    }
}

    void deleteall(node*  &temp){
        
        if(temp!=NULL){
            deleteall(temp->l);
            deleteall(temp->r);
            delete temp;
            temp=NULL;
        }
    }


    int height(node* t){
        int n1=0,n2=0;

        if(t==NULL){
            return 0;
        }
        else{
            if(t->l!=NULL){
                n1++;
                n1+=height(t->l);

            }
            if(t->r!=NULL){
                n2++;
                n2+=height(t->r);
            }

            return n1+n2;
        }
    }
		void sumpath(vector<int> p,node* leaf){
			if(leaf->l==NULL&&leaf->r==NULL){
				total.push_back(p);
				return; 
			}
			else if(leaf->l!=NULL){
				p.push_back(leaf->val);
				sumpath(p,leaf->l);
				p.pop_back();
			}
			else if(leaf->r!=NULL){
				p.push_back(leaf->val);
				sumpath(p,leaf->r);
				p.pop_back();
			}
		}
		void sumpath1(vector<int> p,node* leaf){
			if(leaf!=NULL){
				p.push_back(leaf->val);
				sumpath1(p,leaf->l);
				p.pop_back();
				sumpath1(p,leaf->r);
				p.pop_back();
			}
			else{
				total.push_back(p);
				return ;
			}
		}
					
		vector<vector<int> > returnvector(){
			return total;
		}

};
int main(){
	vector<int> p;
	int arr[]={34 ,29 ,65, 21, 31, 43, 87, 56 ,28 ,30};
    binarytree t;
	for(int i=0;i<10;i++){
		t.insert(arr[i]);
	}
   // cout<<t.getroot()->val<<endl;
    //t.in_order(t.getroot());
    t.sumpath1(p,t.getroot());
   // t.print(t.getroot(),5);
    
    vector<vector<int> > path;
    path=t.returnvector();
    cout<<endl<<endl;
    for(int i=0;i<path.size();i++){
    	int sum=0;
    	for(int j=0;i<path[i].size();j++){
    		sum+=path[i][j];
		}
		cout<<sum<<' ';
	}

}
