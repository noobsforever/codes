#include<iostream>
using namespace std;
void bubblesort(int *arr,int n){
	for(int i=0;i<n;i++){
		for(int j=0;j<n-i-1;j++){
			if(arr[j]>arr[j+1]){
				int temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
}
void print(int arr[],int n){
	for(int i=0;i<n;i++){
		cout<<arr[i]<<' ';
	}
	cout<<endl;
}
int main(){
	int size=7;
	int arr[size]={4,8,6,7,2,1,5};
	print(arr,size);
	bubblesort(arr,size);
	print(arr,size);
	
}
