#include<iostream>
using namespace std;
void selection(int *arr,int n){
	int min;
	for(int i=0;i<n-1;i++){
		min=i;
		for(int j=i+1;j<n;j++){
			if(arr[j]<arr[min]){
				min=j;
			}
			
		}
		if(min!=i){
				int temp=arr[min];
				arr[min]=arr[i];
				arr[i]=temp;
			}
	}
}
void print(int arr[],int n){
	for(int i=0;i<n;i++){
		cout<<arr[i]<<' ';
	}
	cout<<endl;
}
int main(){
	int size=7;
	int arr[size]={4,8,6,7,2,1,5};
	print(arr,size);
	selection(arr,size);
	print(arr,size);
	
	
}
