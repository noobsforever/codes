#include<iostream>
using namespace std;
void shellsort(int *arr,int n){
	int gap,temp;
	gap=n/2;
	while(gap>0){
		for(int i=gap;i<n;i++){
			temp=arr[i];
			int j=0;
			for(j=i;j>=gap&&arr[j-gap]>temp;j-=gap){
				arr[j]=arr[j-gap];
			}
			arr[j]=temp;
		}
		gap/=2;
	}
}
void print(int arr[],int n){
	for(int i=0;i<n;i++){
		cout<<arr[i]<<' ';
	}
	cout<<endl;
}
int main(){
	int size=7;
	int arr[size]={4,8,6,7,2,1,5};
	print(arr,size);
	shellsort(arr,size);
	print(arr,size);
	
	
}
