#include<iostream>
#include "linkedlist.h"
using namespace std;


int main(){
    priorityqueue l;

    l.append(1,4);
  //  cout<<"1 ";
    l.append(2,1);
  //cout<<"2 ";
    l.append(3,3);
    //cout<<"3 ";
    l.append(4,2);
    //cout<<"4 ";
    l.append(5,0);
    //cout<<"5 ";
    l.append(6,5);
    //cout<<"6 ";
    l.display();
    cout<<endl;
     cout<<l.gethead()->value<<' ';
     cout<<endl<<l.gettail()->value<<' ';
}
