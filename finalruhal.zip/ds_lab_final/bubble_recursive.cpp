#include<iostream>
using namespace std;
void bubbleSort(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] > arr[i + 1]) {
            swap(arr[i], arr[i+1]);
        }
    }
    if (n - 1 > 1) {
        bubbleSort(arr, n - 1);
    }
}
//insertion
void is(int arr[], int n) 
{ 
    if (n <= 1) 
        return; 
  
    is( arr, n-1 ); 
  
    int last = arr[n-1]; 
    int j = n-2; 
  
    while (j >= 0 && arr[j] > last) 
    { 
        arr[j+1] = arr[j]; 
        j--; 
    } 
    arr[j+1] = last; 
} 
//selection
int minIndex(int a[], int i, int j) 
{ 
    if (i == j) 
        return i; 
  
    int k = minIndex(a, i + 1, j); 
  
    return (a[i] < a[k])? i : k; 
} 
  
void recurSelectionSort(int a[], int n, int index = 0) 
{ 
    if (index == n) 
       return; 
  
    int k = minIndex(a, index, n-1); 
  
    if (k != index) 
       swap(a[k], a[index]); 
  
    recurSelectionSort(a, n, index + 1); 
} 
int main(){
	int arr[]={5,4,3,2,1};
	recurSelectionSort(arr,5);
	for(int i=0;i<5;i++){
		cout<<arr[i]<<' ';
	}
}
