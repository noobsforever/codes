#include<iostream>
#define r 4
using namespace std;

int k=0;
void printarr(int arr[][r]);
bool rowcolcheck(int arr[][r],int row,int col){
    int c=0;
    for(int i=0;i<col;i++){
        if(arr[row][i]){
            return false;
        }}
        for(int i=row,j=col;i<r&&j>=0;i++,j--){
            if(arr[i][j]){
                return false;
            }
        }
        for(int i=row,j=col;i>=0&&j>=0;i--,j--){
            if(arr[i][j]){
                return false;
            }
        }
        return true;
    }
bool nqueen(int arr[][r],int col){
    if(col>=r){
    	return true;
	}
	for(int i=0;i<r;i++){
		if(rowcolcheck(arr,i,col)){
			arr[i][col]=1;
			if(nqueen(arr,col+1)){
				return true;
			}
		
			else{
			
			arr[i][col]=0;
	}
		}
	}
	return false;
    
}
void printarr(int arr[][r]){
	for(int i=0;i<r;i++){
            for(int j=0;j<r;j++){
                cout<<" "<<arr[i][j];
            }
            cout<<endl;
        }
	
}
int main(){
    int arr[r][r];
    for(int i=0;i<r;i++){
        for(int j=0;j<r;j++){
            arr[i][j]=0;
        }
    }
    
    if(nqueen(arr,0)){
    	printarr(arr);
   		 	
	}
}
