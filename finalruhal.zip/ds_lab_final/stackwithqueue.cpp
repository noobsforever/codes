#include<iostream>
#include<queue>
using namespace std;
class stack{
	queue<int> q1,q2;
	public:
		void push(int n1){
			while(!q1.empty()){
				q2.push(q1.front());
				q1.pop();
			}
			q1.push(n1);
			while(!q2.empty()){
				q1.push(q2.front());
				q2.pop();
			}
		}
		int pop(){
			int n=q1.front();
			q1.pop();
			return n;
		}
};
int main(){
	stack q1;
	for(int i=0;i<5;i++){
		q1.push(i+1);
	}
	for(int i=0;i<5;i++){
		cout<<q1.pop()<<" ";
	}
}
