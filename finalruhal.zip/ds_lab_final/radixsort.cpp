#include<iostream>
using namespace std;
int getmax(int arr[],int n){
    int max=arr[0];
    for(int i=0;i<n;i++){
        if(max<arr[i]){
            max=arr[i];
        }
    }
    return max;
}
void intit(int *arr,int n){
	for(int i=0;i<n;i++){
		arr[i]=0;
	}
}
void countsort(int *arr,int n,int exp){
    int *final=new int[n];
    int n1=getmax(arr,n)+1;
    int *count=new int[n];
    intit(count,n1);
    for(int i=0;i<n;i++){
        count[(arr[i]/exp)%10]++;
    }
    for(int i=1;i<=n1;i++){
        count[i]+=count[i-1];

    }
    for(int i=0;i<n;i++){
        final[count[(arr[i]/exp)%10]-1]=arr[i];
        count[(arr[i]/exp)%10]--;
    }
    for(int i=0;i<n;i++){
        arr[i]=final[i];
    }
}
void print(int arr[], int n) 
{ 
    cout << "Array :\n"; 
  
    for (int i = 0; i < n; ++i) 
        cout << arr[i] << " "; 
    cout << "\n"; 
} 
void radix(int *arr,int n){
    int m=getmax(arr,n);
    for(int i=1;m/i>0;i*=10){
        countsort(arr,n,i);
    }
}

int main(){
    int arr[]={1,2,9,6,7,5,3,4};
    print(arr,8);
    radix(arr,8);
    print(arr,8);
}
