#include <iostream>
using namespace std;
class node
{
public:
    int value;
    node *nxtptr;
};
class linkedlist
{
    node *head;
    node *tail;
    int c;

public:
    linkedlist()
    {
        c = 0;
        head = NULL;
        tail = NULL;
    }
    void addfront(int n){
    	node* temp=new node;
    	temp->value=n;
    	temp->nxtptr=NULL;
    	if(head==NULL){
    		head=temp;
    		tail=temp;
		}
		else{
			temp->nxtptr=head;
			head=temp;
		}
	}
    void append(int n)
    {
        node *temp = new node;
        temp->value = n;
        temp->nxtptr = NULL;
        if (head == NULL)
        {
            head = temp;
            tail = temp;
            c++;
        }
        else
        {
            tail->nxtptr = temp;
            tail = tail->nxtptr;
            c++;
        }
    }
	void deletenode(int n){
		node *temp= head;
		if(head->value==n){
			head=head->nxtptr;
			delete temp;
			return;
		}
		while(temp!=NULL){
			if(temp->nxtptr->value==n){
				node *temp1=temp->nxtptr;
				temp->nxtptr=temp->nxtptr->nxtptr;
				delete temp1;
				return ;
			}
			temp=temp->nxtptr;
		}
		 cout<<"not found";
	}
    void display()
    {
        node *temp = head;
        if (head == NULL)
        {
            cout << "list empty";
        }
        else
        {
			while(temp!=NULL){
				cout<<temp->value<<' ';
				temp=temp->nxtptr;
			}
        }
    }
    node *gettail()
    {
        return tail;
    }
    node *gethead()
    {
        return head;
    }
};
