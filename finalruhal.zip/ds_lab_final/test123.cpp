#include <iostream>
#include "linkedlist.h";
using namespace std;
int main(){
	linkedlist l1;
	for(int i=0;i<10;i++){
	l1.append(i+1);
	}
	l1.display();
	l1.deletenode(10);
	cout<<endl;
	l1.display();
}
