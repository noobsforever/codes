#include<iostream>
using namespace std;
struct node{
    int val;
    node* nxt;
    node*pre;

};
class doubly{
    node* head;
    node* tail;
    int count;
    public:
    doubly(){
        head=NULL;
        tail=NULL;
        count=0;
    }
    void addfront(int n){
    	node*temp=new node;
    	temp->val=n;
    	temp->pre=NULL;
    	temp->nxt=head;
    	if(head==NULL){
    		head=temp;
    		tail=temp;
		}
		else{
			head->pre=temp;
			head=temp;
			
		}
	}
    void append(int n){
        node *temp= new node;
        temp->val=n;
        temp->nxt=NULL;
        temp->pre=tail;
        if(head==NULL){
            head=temp;
          	tail=temp;
        }
        else{
            tail->nxt=temp;  
            tail=tail->nxt;

        }
    }
    void check(int n){
    	node* temp1=head;
    	node*temp2;
        int sum;
      //  doubly l;
      bool flag=false;
    	while(temp1!=NULL){
            temp2=temp1->nxt;
    		while(temp2!=NULL ){
                sum=(temp1->val)+(temp2->val);
                if(sum==n){
                     cout<<temp1->val<<","<<temp2->val<<endl;
                     flag=true;
                     	break;
                }
                if(temp2->val>n){
                
				}
    		temp2=temp2->nxt;
			}
            temp1=temp1->nxt;
            
//            if(temp1->val>n){
//                	break;
//				}
		}
      //  l.dis();
	if(!flag){
		cout<<"No pairs found\n";
	}
        
        
	}

 
    void display(){
        node *temp=head;
        while(temp!=NULL){
            cout<<temp->val<<endl;
            temp=temp->nxt;
        }
    }
    
     void sort(){
        node* temp=head;
        node* temp2=head;
        int n;
        while(temp2->nxt!=NULL){
		
      while (temp->nxt!=NULL)  
		{
			if (temp->val>temp->nxt->val )
			{
				
				n = temp->val;
				temp->val = temp->nxt->val;
				temp->nxt->val = n;

					
	
			}
			temp = temp->nxt;
		//cout<<"i\n";
		
		
		
	}
	temp=head;
	temp2=temp2->nxt;
	}
	
        
        
    }
};
