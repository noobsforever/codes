#include <iostream>
#include <conio.h>
#include <stdlib.h>
using namespace std;

void heapify(int *arr,int n,int t){
    int largest=t;
    int l=(2*t)+1;
    int r=(2*t)+2;

    if(l<n&&arr[l]>arr[largest]){
        largest=l;
    }
    if(r<n&&arr[r]>arr[largest]){
        largest=r;
    }

    if(largest!=t){
        swap(arr[largest],arr[t]);
     heapify(arr,n,largest);
    }
   
}
void printHeap(int arr[], int n) 
{ 
    cout << "Array representation of Heap is:\n"; 
  
    for (int i = 0; i < n; ++i) 
        cout << arr[i] << " "; 
    cout << "\n"; 
} 

void heapsort(int *arr,int n){
    for(int i=(n/2)-1;i>=0;i--){
        heapify(arr,n,i);
    }
    for(int i=n-1;i>=0;i--){
        swap(arr[0],arr[i]);
        heapify(arr,i,0);
    }
}
  
void buildheap(int *arr,int n){
    for(int i=(n/2)-1;i>=0;i--){
        heapify(arr,n,i);
    }
}


int main(){

    //          0, 1, 2 ,3 ,4 , 5 , 6 , 7 ,8 ,9 ,10
   int arr[]= { 1, 3, 5, 4, 6, 13, 10, 9, 8, 15, 17 };
    buildheap(arr,11);
    printHeap(arr,11);

}