#include<iostream>
#define n 6
using namespace std;
void merge(int*,int,int,int);
void mergesort(int *arr,int low,int high){
	int mid;
	if(low<high){
		
		mid=(low+high)/2;
		mergesort(arr,low,mid);
		mergesort(arr,mid+1,high);
		merge(arr,low,mid,high);
		
		
	}
}
void merge(int *arr,int low,int mid,int high){
	int i=low,k=low;
	int j=mid+1;
	int c[n];
	while(i<=mid&&j<=high){
		if(arr[i]<arr[j]){
			c[k]=arr[i];
			k++;
			i++;
		}
		else{
			c[k]=arr[j];
			k++;
			j++;
		}
	}
	while(i<=mid){
		c[k]=arr[i];
		k++;
		i++;
	}
	while(j<=high){
		c[k]=arr[j];
		j++;
		k++;
	}
	for(int m=low;m<k;m++){
		arr[m]=c[m];
	}
}
int main(){
	int arr[]={3,2,8,9,5,7};
	mergesort(arr,0,n-1);
	
	for(int i=0;i<n;i++){
		cout<<arr[i]<<' ';
	}
}
