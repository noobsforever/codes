#include <iostream>
#include <bits/stdc++.h> 
#include <string.h> 
using namespace std;
int getmax(int arr[],int n){
    
    int max=arr[0];
    for(int i=0; i<n;i++){
        if(max<arr[i]){
            max=arr[i];
        }
    }
    return max;
}
void intit(int *arr,int n){
	for(int i=0;i<n;i++){
		arr[i]=0;
	}
}
void countsort(int *arr,int n){
    
    int *final=new int[n];
    int n1=getmax(arr,n)+1;
    int *count=new int[n1];
    intit(count,n1);
    for(int i=0;arr[i]<n1;i++){
    //	cout<<"loop 1 ";
        count[arr[i]]++;

    }
	cout<<endl;
    for(int i=1;i<=n1;i++){
	//	cout<<"loop 2 ";
        count[i]+=count[i-1];
    }
    for(int i=0;arr[i]<n1;i++){
    //	cout<<"loop 3 ";
        final[count[arr[i]]-1]=arr[i];
        count[arr[i]]--;

    }

    for(int i=0;i<n;i++){
    //	cout<<"loop 4 ";
        arr[i]=final[i];
    }


}
void print(int arr[], int n) 
{ 
    cout << "Array :\n"; 
  
    for (int i = 0; i < n; ++i) 
        cout << arr[i] << " "; 
    cout << "\n"; 
} 






int main(){
    int arr[]={1,2,9,6,7,5,3,4};
    print(arr,8);
    countsort(arr,8);
    print(arr,8);
}
