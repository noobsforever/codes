

#include<iostream>
using namespace std;
struct node{
    int val;
    node* nxt;
};
class queue{
    node* head;
    node* tail;
    int count;
    public:
    queue(){
        head=NULL;
        tail=NULL;
        count=0;
    }
    void enqueue(int n){
        node* temp=new node;
        temp->val=n;
        temp->nxt=NULL;
        if(head==NULL){
            head=temp;
            tail=temp;
            count++;
        }
        else{
            
            tail->nxt=temp;
            tail=tail->nxt;
            count++;
        }
        
    }
    void display(){

        if(head==NULL){
            cout<<"\nEmpty\n";
            return ;
        }
        node* temp=head;
        
        while(temp!=NULL){
            cout<<temp->val<<endl;
            temp=temp->nxt;
        }
        
    }
   
    int getcount(){
        return count;

    }
    node* gethead(){
    	return head;
	}
	node* gettail(){
    	return tail;
	}
	 void copy(queue &q1)
     {
         node *temp=q1.gethead();
         while(temp!=NULL){
             enqueue(temp->val);
             temp=temp->nxt;
         }
     }
	


    int dequeue(){
        int n;
        if(head==NULL){
            return 0;
        }
        node *temp=head;
        head=head->nxt;

        if(head==NULL){
            tail=NULL;
        }
        n=temp->val;
        delete temp;
        count--;
        return n;

        
    }



    void sort(){
        node *temp=head;
        int n;
        for(int i=0;i<count;i++){
            temp=head;
            for(int j=0;j<count-i-1;j++){
                if(temp->val<temp->nxt->val){
                    n=temp->val;
                    temp->val=temp->nxt->val;
                    temp->nxt->val=n;
                }
                temp=temp->nxt;

            }
        }
    }

    void emptylist(){
        int n=count;
        for(int i=0;i<n;i++){
            dequeue();
        }
    }


    bool operator==(queue &q1){
       if(q1.gethead()==NULL||head==NULL){
            return false;
        }
        if(q1.getcount()!=count){
            return false;
        }
        node *temp1=head;
        node *temp2=q1.gethead();
        
        while(temp1!=NULL||temp2!=NULL){
            if(temp1->val!=temp2->val){
                return false;
            }
            temp1=temp1->nxt;
            temp2=temp2->nxt;
        }
        return true;
    }



    void reverse(){
        node *temp=head;
        node *next=NULL,*prev=NULL;
        while(temp!=NULL){
            next=temp->nxt;
            temp->nxt=prev;
            prev=temp;
            temp=next;
        }
        head=prev;
    }



    void reversequeue(queue q1){
        emptylist();
        queue q3;
        q3.copy(q1);
        q3.reverse();
        int n=q3.getcount();
        for(int i=0;i<n;i++){
            enqueue(q3.dequeue());
        }
        q3.emptylist();
    }
};