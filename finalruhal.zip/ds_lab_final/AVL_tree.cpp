#include<bits/stdc++.h> 
#include<vector>
#include<iostream>
using namespace std; 

class Node 
{ 
	public: 
	int key; 
	Node *left; 
	Node *right; 
	int height; 
}; 

int max(int a, int b); 

int height(Node *N) 
{ 
	if (N == NULL) 
		return 0; 
	return N->height; 
} 

int max(int a, int b) 
{ 
	return (a > b)? a : b; 
} 

Node* newNode(int key) 
{ 
	Node* node = new Node(); 
	node->key = key; 
	node->left = NULL; 
	node->right = NULL; 
	node->height = 1;  
					
	return(node); 
} 

Node *rightRotate(Node *y) 
{ 
	Node *x = y->left; 
	Node *T2 = x->right; 

	x->right = y; 
	y->left = T2; 

	y->height = max(height(y->left), 
					height(y->right)) + 1; 
	x->height = max(height(x->left), 
					height(x->right)) + 1; 

	return x; 
} 

Node *leftRotate(Node *x) 
{ 
	Node *y = x->right; 
	Node *T2 = y->left; 

	y->left = x; 
	x->right = T2; 

	x->height = max(height(x->left),	 
					height(x->right)) + 1; 
	y->height = max(height(y->left), 
					height(y->right)) + 1; 

	return y; 
} 

int getBalance(Node *N) 
{ 
	if (N == NULL) 
		return 0; 
	return height(N->left) - height(N->right); 
} 
Node* insert(Node* node, int key) 
{ 
	if (node == NULL) 
		return(newNode(key)); 

	if (key < node->key) 
		node->left = insert(node->left, key); 
	else if (key > node->key) 
		node->right = insert(node->right, key); 
	else  
		return node; 

	node->height = 1 + max(height(node->left), 
						height(node->right)); 

	int balance = getBalance(node); 


	if (balance > 1 && key < node->left->key) 
		return rightRotate(node); 

	if (balance < -1 && key > node->right->key) 
		return leftRotate(node); 

	if (balance > 1 && key > node->left->key) 
	{ 
		node->left = leftRotate(node->left); 
		return rightRotate(node); 
	} 

	if (balance < -1 && key < node->right->key) 
	{ 
		node->right = rightRotate(node->right); 
		return leftRotate(node); 
	} 

	return node; 
} 

bool commonancestor(Node *leaf,int val1,int val2){
	if(leaf !=NULL){
		if(leaf->left->key==val1){
			if(commonancestor(leaf->right,val1,val2)){
			cout<<"ancestor: "<<leaf->key;
			}
			
			return true;
		}
		if(leaf->right->key==val1){
			if(commonancestor(leaf->left,val1,val2)){
			cout<<"ancestor: "<<leaf->key;
			}
			
			return true;
		}
		if(leaf->left->key==val2){
			if(commonancestor(leaf->right,val1,val2)){
			cout<<"ancestor: "<<leaf->key;
			}
			
			return true;
		}
		if(leaf->right->key==val2){
			if(commonancestor(leaf->left,val1,val2)){
			cout<<"ancestor: "<<leaf->key;
			}
			
			return true;
		}
		cout<<"!";
		commonancestor(leaf->left,val1,val2);
		commonancestor(leaf->right,val1,val2);
		return false;
		
		
	}
	
	return false;
}
void inOrder(Node *root,vector<int> *v1);
void kthlargest(Node *leaf,int n){
	vector<int> v1;
			
	inOrder(leaf,&v1);
	n=v1.size()-n;
	cout<<v1[n];
	cout<<endl;
}
Node* common(Node*leaf,int val1,int val2){
	if(leaf!=NULL){
		if(val1>leaf->key&&val2>leaf->key){
		return common(leaf->right,val1,val2);
		}
		if(val1<leaf->key&&val2<leaf->key){
			return common(leaf->left,val1,val2);
		}
		return leaf;
	}
	return NULL;
}

void inOrder(Node *root,vector<int> *v1) 
{ 
	if(root != NULL) 
	{ 
	 
		inOrder(root->left,v1); 
		//	cout << root->key << " ";
			v1->push_back(root->key);
		inOrder(root->right,v1); 
	} 
} 

int main() 
{ 
	Node *root = NULL; 
	
	root = insert(root, 10); 
	root = insert(root, 5); 
	root = insert(root, 20); 
	root = insert(root, 1); 
	root = insert(root, 7); 
	root = insert(root, 17); 
	root = insert(root, 25);
	
//	cout << "Preorder traversal of the "
			"constructed AVL tree is \n"; 

	//cout<<endl;
	//cout<<common(root,5,20+)->key;
	kthlargest(root,6);
	return 0; 
} 


