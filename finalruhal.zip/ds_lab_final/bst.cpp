#include<iostream>
using namespace std;
class node{
    public:
    int val;
    node* l,*r;
};
class binarytree{
    node *root;
    bool o;
    public:
    binarytree(){
        root=NULL;
        o=true;
    }
    
   void insert(int n){
       
        
       if(root==NULL){
            root=new node;
            root->val=n;
            root->l=NULL;
            root->r=NULL;
        }
        else{
            insert_node(n,root);
        }

        
    }
    void insert_node(int n,node* leaf){
        node*temp=new node;
        temp->r=NULL;
        temp->val=n;
        temp->l=NULL;
        if(leaf->val>n){
            if(leaf->l==NULL){
                leaf->l=temp;
            }
            else
            {
                insert_node(n,leaf->l);
            }
            }
        if(leaf->val<n){
            if(leaf->r==NULL){
                leaf->r=temp;
            }
            else
            {
                insert_node(n,leaf->r);
            }
            }
        

    }
    node*getroot(){
        return root;
    }

    void in_order(node* leaf)
	{
		if(leaf != NULL)
		{
			in_order(leaf->l);
			cout << leaf->val << "\t";
			in_order(leaf->r);
		}
	}
    node* bsearch(int n,node *leaf){
        if(leaf==NULL){
            return NULL;
        }
        else{
            if(leaf->val==n){
                return leaf;
            }
            else if(leaf->val>n){
                bsearch(n,leaf->l);
            }
            else if(leaf->val<=n){
                bsearch(n,leaf->r);
            }
        }
    }
   void  print(node *r, int gap)
{
    if (r == NULL)
    {
        return;
    }
    else
    {
        gap += 10;
        print(r->r, gap);
        cout << endl;
        for (int i = 10; i < gap; i++)
        {
            cout << " ";
        }
        cout << r->val << "\n";
        print(r->l, gap);
    }
}



};
int main(){
    binarytree t;
	t.insert(10);
	t.insert(5);
	t.insert(15);
	t.insert(40);
    t.insert(30);
    
   // cout<<t.getroot()->val<<endl;
    //t.in_order(t.getroot());
	t.print(t.getroot(),5);

    if(t.bsearch(500,t.getroot())==NULL){
        cout<<"\nfalse";
    }
    else{
        cout<<"\ntrue";
    }

}