#include<iostream>
#include<vector>
#include<stack>
using namespace std;
#define n 5
vector<int> graph[7];
bool visited[7]={false};
void dfs(int s){
	stack<int> st;
	st.push(s);
	visited[s]=true;
	while(!st.empty()){
		int u=st.top();
		cout<<u<<' ';
			st.pop();
			for(int i=0;i<graph[u].size();i++){
				if(!visited[graph[u][i]]){
					st.push(graph[u][i]);
					visited[graph[u][i]]=true;
				}
			}
	}
	
	
}
void addedge(int u,int v){
	graph[u].push_back(v);
}
int main(){
	addedge(1,2);
	addedge(1,3);
	addedge(2,4);
	addedge(3,4);
	addedge(3,5);
	addedge(4,6);
	addedge(4,3);
	addedge(6,7);
	addedge(6,5);
	addedge(7,5);
	addedge(5,3);
	addedge(5,6);
    dfs(3);

}
