#include<iostream>
#include<stdlib.h>
using namespace std;
template <class T>
class stack{
    T *arr;
    int n;
    int top;
    public:
   
    stack() {
        top=-1;
        n=0;
       
    }
    void push(T n1){
        
       if(isempty()){
        n++;
        arr=(T*)calloc(n,sizeof(T));
        top++;
        arr[top]=n1;
       
       }
       else{
       top++;
       n++;
       arr=(T*)realloc(arr,n*sizeof(T));
       arr[top]=n1;
       }
        
    }
    T pop(){
         if(isempty())
        {
            cout<<"empty\n";
            return 0;

        }
        
        T n1=arr[top];
        n--;
        arr=(T*)realloc(arr,n*sizeof(T));
        top--;
       return n1;

    }
    bool isfull(){
        if(n-1==top){
            return true;
        }
        return false;
    }
    bool isempty(){
        if(top<0){
            return true;
        }
        return false;
    }
    void peek(T n1){
        if(isempty()||n1>n-1)
        {
            cout<<"empty\n";
            return ;

        }
        cout<<arr[n]<<endl; 


    }
    T Top(){
        return arr[n-1];
    }
    int size(){
        return n;
    }
    void display(){
        if(isempty()){
            cout<<"empty\n";
            return ;
        }
        for(int i=0;i<n;i++){
            cout<<arr[i]<<" ";
        }
    }
    void change(T n1,int pos){
        if(isempty()||pos>n-1){
            cout<<"empty\n";
            return ;
        }
        arr[pos]=n1;
        
    }
    
};