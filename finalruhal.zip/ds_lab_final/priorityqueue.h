#include <iostream>
using namespace std;
class node
{
public:
    int value;
    node *nxtptr;
    int p;
};
class priorityqueue
{
    node *head;
    node *tail;
    int c;

public:
    priorityqueue()
    {
        c = 0;
        head = NULL;
        tail = NULL;
    }
    void addfront(int n,int p1){
    	node* temp=new node;
    	temp->value=n;
        temp->p=p1;
    	temp->nxtptr=NULL;
    	if(head==NULL){
    		head=temp;
    		tail=temp;
		}
		else{
			temp->nxtptr=head;
			head=temp;
		}
	}
    void append(int n,int p1)
    {  
        node *temp = new node;
        temp->value = n;
        temp->p=p1;
        temp->nxtptr = NULL;
       node* temp2=head;
        if(head == NULL){
            head=temp;
            tail=temp;
        }
        else{
            if(head->p>p1){
                addfront(n,p1);
            }
            else{
                while(temp2->nxtptr!=NULL&&temp2->nxtptr->p<p1){
                    temp2=temp2->nxtptr;
                }
                temp->nxtptr=temp2->nxtptr;
                temp2->nxtptr=temp;

            }

        }
        c++;

    }
    int dequeue(){
        if(head == NULL){
            return 0;
        }
        node*temp=head;
        int n=temp->value;
        head=temp->nxtptr;
        c--;
        delete temp;
        return n;
    }

    void display()
    {
        node *temp = head;
        if (head == NULL)
        {
            cout << "list empty";
        }
        else
        {
			while(temp!=NULL){
				cout<<temp->value<<' ';
				temp=temp->nxtptr;
			}
        }
    }
    node *gettail()
    {
        return tail;
    }
    node *gethead()
    {
        return head;
    }
};
